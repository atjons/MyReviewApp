import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { ComparisonForm } from '../products/comparison-form';
import { Product } from '@shared/schema';

export function ComparisonTool() {
  const { data: products, isLoading, error } = useQuery<Product[]>({
    queryKey: ['/api/products'],
  });

  return (
    <section className="py-16 bg-primary-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="md:flex md:items-center md:justify-between md:space-x-12">
          <div className="md:w-1/2 mb-8 md:mb-0">
            <h2 className="text-3xl font-bold text-neutral-900 mb-4">Compare Software Side by Side</h2>
            <p className="text-lg text-neutral-600 mb-6">
              Our comparison tool makes it easy to evaluate different software options based on features, pricing, ratings, and user reviews.
            </p>
            
            <div className="bg-white rounded-lg border border-neutral-200 p-6 shadow">
              <h3 className="text-lg font-medium text-neutral-900 mb-4">Quick Compare</h3>
              
              {isLoading ? (
                <div className="space-y-4">
                  <div className="animate-pulse">
                    <div className="h-4 bg-neutral-200 rounded w-1/4 mb-1"></div>
                    <div className="h-10 bg-neutral-200 rounded w-full mb-4"></div>
                  </div>
                  <div className="animate-pulse">
                    <div className="h-4 bg-neutral-200 rounded w-1/4 mb-1"></div>
                    <div className="h-10 bg-neutral-200 rounded w-full mb-4"></div>
                  </div>
                  <div className="animate-pulse">
                    <div className="h-4 bg-neutral-200 rounded w-1/4 mb-1"></div>
                    <div className="h-10 bg-neutral-200 rounded w-full mb-4"></div>
                  </div>
                  <div className="h-10 bg-neutral-200 rounded w-full"></div>
                </div>
              ) : error ? (
                <div className="text-red-500 text-center">Failed to load products</div>
              ) : (
                <ComparisonForm products={products || []} />
              )}
            </div>
          </div>
          
          <div className="md:w-1/2">
            <img 
              src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&h=600&q=80" 
              alt="Software comparison" 
              className="rounded-lg shadow-lg w-full object-cover"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
