import React from 'react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { StarRating } from '@/components/ui/star-rating';
import { ArrowRightIcon } from '@/components/ui/icons';
import { useQuery } from '@tanstack/react-query';

export function HeroSection() {
  const { data: latestReviews, isLoading } = useQuery({
    queryKey: ['/api/reviews/latest', { limit: 2 }],
    queryFn: () => fetch('/api/reviews/latest?limit=2').then(res => res.json())
  });

  return (
    <section className="bg-gradient-to-r from-primary-600 to-secondary-700 text-white py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="md:flex md:items-center md:gap-12">
          <div className="md:w-1/2 mb-8 md:mb-0">
            <h1 className="text-4xl font-bold tracking-tight mb-4 md:text-5xl">
              Find the perfect software for your business
            </h1>
            <p className="text-lg mb-6 text-primary-100 md:text-xl">
              Discover, compare and choose the right tools based on authentic user reviews
            </p>
            <div className="flex flex-wrap gap-3">
              <Link href="/categories">
                <Button 
                  variant="secondary" 
                  className="px-5 py-6 text-primary-700 hover:bg-primary-50" 
                  size="lg"
                >
                  Explore Categories
                </Button>
              </Link>
              <Link href="/#top-products">
                <Button 
                  className="px-5 py-6 bg-primary-800 hover:bg-primary-900" 
                  size="lg"
                >
                  Top Rated Software
                </Button>
              </Link>
            </div>
          </div>
          
          <div className="md:w-1/2 relative">
            <div className="bg-white p-6 rounded-lg shadow-lg">
              <h2 className="text-primary-900 font-bold text-xl mb-4">Recently Reviewed</h2>
              
              {isLoading ? (
                <div className="space-y-4">
                  <div className="animate-pulse flex items-start gap-4 mb-4 pb-4 border-b border-neutral-200">
                    <div className="w-10 h-10 bg-neutral-200 rounded-md"></div>
                    <div className="flex-1">
                      <div className="h-4 bg-neutral-200 rounded w-1/3 mb-2"></div>
                      <div className="h-3 bg-neutral-200 rounded w-full mb-2"></div>
                      <div className="h-3 bg-neutral-200 rounded w-2/3"></div>
                    </div>
                  </div>
                  <div className="animate-pulse flex items-start gap-4 mb-4">
                    <div className="w-10 h-10 bg-neutral-200 rounded-md"></div>
                    <div className="flex-1">
                      <div className="h-4 bg-neutral-200 rounded w-1/4 mb-2"></div>
                      <div className="h-3 bg-neutral-200 rounded w-full mb-2"></div>
                      <div className="h-3 bg-neutral-200 rounded w-3/4"></div>
                    </div>
                  </div>
                </div>
              ) : (
                <>
                  {latestReviews?.map((review: any, index: number) => (
                    <div 
                      key={review.id}
                      className={`flex items-start gap-4 mb-4 ${
                        index < latestReviews.length - 1 ? 'pb-4 border-b border-neutral-200' : ''
                      }`}
                    >
                      <img 
                        src={review.product.logo} 
                        alt={`${review.product.name} logo`} 
                        className="w-10 h-10 rounded-md object-cover flex-shrink-0"
                      />
                      <div className="min-w-0 flex-1">
                        <div className="flex justify-between items-start">
                          <h3 className="font-medium text-neutral-900 truncate">
                            {review.product.name}
                          </h3>
                          <div className="flex items-center text-amber-500 ml-2">
                            <StarRating rating={review.rating} size={12} />
                          </div>
                        </div>
                        <p className="text-sm text-neutral-600 line-clamp-2 mt-1">
                          {review.content}
                        </p>
                        <p className="text-xs text-neutral-400 mt-1">
                          Reviewed by <span className="text-primary-600">{review.user.fullName || review.user.username}</span> • {
                            new Date(review.createdAt).toLocaleDateString('en-US', {
                              day: 'numeric',
                              month: 'long',
                              year: 'numeric'
                            })
                          }
                        </p>
                      </div>
                    </div>
                  ))}
                </>
              )}
              
              <Link href="/reviews" className="text-sm font-medium text-primary-600 hover:text-primary-700 flex items-center gap-1">
                See all recent reviews
                <ArrowRightIcon className="h-3.5 w-3.5" />
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
