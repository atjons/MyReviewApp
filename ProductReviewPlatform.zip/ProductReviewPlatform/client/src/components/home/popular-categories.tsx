import React from 'react';
import { Link } from 'wouter';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ArrowRightIcon } from '@/components/ui/icons';
import { getCategoryIcon } from '@/components/ui/icons';
import { useQuery } from '@tanstack/react-query';
import { Category } from '@shared/schema';

export function PopularCategories() {
  const { data: categories, isLoading, error } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
  });

  return (
    <section id="popular-categories" className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-neutral-900 mb-4">Popular Software Categories</h2>
          <p className="text-lg text-neutral-600 max-w-3xl mx-auto">
            Browse the most popular categories to find the right tools for your needs
          </p>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {isLoading ? (
            // Loading skeleton
            Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="bg-neutral-50 border border-neutral-200 rounded-lg p-6 animate-pulse">
                <div className="w-12 h-12 bg-neutral-200 rounded-lg mb-4 mx-auto"></div>
                <div className="h-6 bg-neutral-200 rounded w-3/4 mx-auto mb-2"></div>
                <div className="h-4 bg-neutral-200 rounded w-1/2 mx-auto mb-4"></div>
                <div className="h-5 bg-neutral-200 rounded w-1/3 mx-auto"></div>
              </div>
            ))
          ) : error ? (
            <div className="col-span-full text-center">
              <p className="text-red-500">Failed to load categories</p>
            </div>
          ) : (
            categories?.map((category) => (
              <Link key={category.id} href={`/categories/${category.slug}`}>
                <Card className="bg-neutral-50 border border-neutral-200 rounded-lg p-6 flex flex-col items-center text-center transition-all hover:shadow-md hover:border-primary-300 h-full">
                  <div className="w-12 h-12 bg-primary-100 text-primary-600 rounded-lg flex items-center justify-center mb-4">
                    {getCategoryIcon(category.icon, 24)}
                  </div>
                  <h3 className="text-lg font-medium text-neutral-900 mb-2">{category.name}</h3>
                  <p className="text-sm text-neutral-600 mb-4">{category.productCount} products</p>
                  <span className="text-sm font-medium text-primary-600 group-hover:text-primary-700 flex items-center mt-auto">
                    Browse tools
                    <ArrowRightIcon className="ml-1 h-3.5 w-3.5 transition-transform group-hover:translate-x-1" />
                  </span>
                </Card>
              </Link>
            ))
          )}
        </div>
        
        <div className="mt-12 text-center">
          <Link href="/categories">
            <Button variant="outline" className="gap-2">
              View all categories
              <ArrowRightIcon className="h-4 w-4" />
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
}
