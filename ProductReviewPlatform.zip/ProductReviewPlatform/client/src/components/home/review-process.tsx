import React from 'react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import {
  UserVoiceIcon,
  CheckboxIcon,
  ShieldIcon,
  EditIcon
} from '@/components/ui/icons';

export function ReviewProcess() {
  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-neutral-900 mb-4">How Our Review Process Works</h2>
          <p className="text-lg text-neutral-600 max-w-3xl mx-auto">
            We collect verified reviews from real users to help you make informed decisions
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="text-center">
            <div className="w-16 h-16 rounded-full bg-primary-100 text-primary-600 flex items-center justify-center mx-auto mb-4">
              <UserVoiceIcon className="h-8 w-8" />
            </div>
            <h3 className="text-xl font-bold text-neutral-900 mb-2">Authentic Reviews</h3>
            <p className="text-neutral-600">
              Every review is verified and comes from real users with genuine experiences using the software.
            </p>
          </div>
          
          <div className="text-center">
            <div className="w-16 h-16 rounded-full bg-primary-100 text-primary-600 flex items-center justify-center mx-auto mb-4">
              <CheckboxIcon className="h-8 w-8" />
            </div>
            <h3 className="text-xl font-bold text-neutral-900 mb-2">Comprehensive Analysis</h3>
            <p className="text-neutral-600">
              Our review process captures detailed feedback across multiple criteria, not just overall satisfaction.
            </p>
          </div>
          
          <div className="text-center">
            <div className="w-16 h-16 rounded-full bg-primary-100 text-primary-600 flex items-center justify-center mx-auto mb-4">
              <ShieldIcon className="h-8 w-8" />
            </div>
            <h3 className="text-xl font-bold text-neutral-900 mb-2">Unbiased Results</h3>
            <p className="text-neutral-600">
              We never accept payment for reviews or manipulate ratings. What you see is what real users think.
            </p>
          </div>
        </div>
        
        <div className="mt-16 text-center">
          <Link href="/review">
            <Button 
              variant="secondary" 
              className="gap-2"
            >
              Write a review
              <EditIcon className="h-4 w-4" />
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
}
