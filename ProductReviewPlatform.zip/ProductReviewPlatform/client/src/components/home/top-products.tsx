import React from 'react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { StarRating } from '@/components/ui/star-rating';
import { ArrowRightIcon } from '@/components/ui/icons';
import { useQuery } from '@tanstack/react-query';
import { Product } from '@shared/schema';
import { ProductCard } from '@/components/products/product-card';

export function TopProducts() {
  const { data: products, isLoading, error } = useQuery<Product[]>({
    queryKey: ['/api/products/top', { limit: 3 }],
  });

  return (
    <section id="top-products" className="py-16 bg-neutral-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-neutral-900 mb-4">Top-Rated Software Products</h2>
          <p className="text-lg text-neutral-600 max-w-3xl mx-auto">
            The highest-rated software products based on verified user reviews
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {isLoading ? (
            // Loading skeleton
            Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="bg-white border border-neutral-200 rounded-lg shadow overflow-hidden animate-pulse">
                <div className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center">
                      <div className="w-12 h-12 bg-neutral-200 rounded-md"></div>
                      <div className="ml-3">
                        <div className="h-4 bg-neutral-200 rounded w-24 mb-2"></div>
                        <div className="h-3 bg-neutral-200 rounded w-16"></div>
                      </div>
                    </div>
                    <div className="flex flex-col items-end">
                      <div className="h-4 w-10 bg-neutral-200 rounded mb-1"></div>
                      <div className="h-3 w-16 bg-neutral-200 rounded"></div>
                    </div>
                  </div>
                  <div className="h-3 bg-neutral-200 rounded mb-2 w-full"></div>
                  <div className="h-3 bg-neutral-200 rounded mb-2 w-full"></div>
                  <div className="h-3 bg-neutral-200 rounded mb-6 w-3/4"></div>
                  <div className="flex flex-wrap gap-2 mb-6">
                    <div className="h-4 bg-neutral-200 rounded w-20"></div>
                    <div className="h-4 bg-neutral-200 rounded w-24"></div>
                    <div className="h-4 bg-neutral-200 rounded w-16"></div>
                  </div>
                  <div className="border-t border-neutral-200 pt-4 mt-auto">
                    <div className="flex justify-between items-center">
                      <div className="h-4 bg-neutral-200 rounded w-20"></div>
                      <div className="h-4 bg-neutral-200 rounded w-16"></div>
                    </div>
                  </div>
                </div>
              </div>
            ))
          ) : error ? (
            <div className="col-span-full text-center">
              <p className="text-red-500">Failed to load top products</p>
            </div>
          ) : (
            products?.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))
          )}
        </div>
        
        <div className="mt-12 text-center">
          <Link href="/products">
            <Button className="gap-2">
              View all top products
              <ArrowRightIcon className="h-4 w-4" />
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
}
