import React from 'react';
import { Link } from 'wouter';
import { 
  StackIcon, 
  TwitterIcon, 
  LinkedInIcon, 
  FacebookIcon, 
  InstagramIcon 
} from '@/components/ui/icons';

export function Footer() {
  return (
    <footer className="bg-neutral-900 text-neutral-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-5 gap-8">
          <div className="md:col-span-2">
            <Link href="/">
              <div className="flex items-center gap-2 mb-6 cursor-pointer">
                <div className="h-8 w-8 rounded-md bg-primary text-white flex items-center justify-center">
                  <StackIcon className="h-5 w-5" />
                </div>
                <span className="text-xl font-bold text-white">SoftwareReviews</span>
              </div>
            </Link>
            
            <p className="text-neutral-400 mb-6">
              Helping you find the right software for your business with authentic user reviews and detailed comparisons.
            </p>
            
            <div className="flex space-x-4">
              <a href="#" className="text-neutral-400 hover:text-white">
                <TwitterIcon className="h-5 w-5" />
              </a>
              <a href="#" className="text-neutral-400 hover:text-white">
                <LinkedInIcon className="h-5 w-5" />
              </a>
              <a href="#" className="text-neutral-400 hover:text-white">
                <FacebookIcon className="h-5 w-5" />
              </a>
              <a href="#" className="text-neutral-400 hover:text-white">
                <InstagramIcon className="h-5 w-5" />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-white font-medium text-lg mb-4">Categories</h3>
            <ul className="space-y-3">
              <li><Link href="/categories/crm" className="text-neutral-400 hover:text-white">CRM Software</Link></li>
              <li><Link href="/categories/project-management" className="text-neutral-400 hover:text-white">Project Management</Link></li>
              <li><Link href="/categories/communication" className="text-neutral-400 hover:text-white">Communication</Link></li>
              <li><Link href="/categories/marketing" className="text-neutral-400 hover:text-white">Marketing Tools</Link></li>
              <li><Link href="/categories/analytics" className="text-neutral-400 hover:text-white">Analytics</Link></li>
              <li><Link href="/categories" className="text-neutral-400 hover:text-white">View All</Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-white font-medium text-lg mb-4">Resources</h3>
            <ul className="space-y-3">
              <li><a href="#" className="text-neutral-400 hover:text-white">Blog</a></li>
              <li><a href="#" className="text-neutral-400 hover:text-white">Buying Guides</a></li>
              <li><a href="#" className="text-neutral-400 hover:text-white">Comparison Tools</a></li>
              <li><a href="#" className="text-neutral-400 hover:text-white">Review Guidelines</a></li>
              <li><a href="#" className="text-neutral-400 hover:text-white">Webinars</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-white font-medium text-lg mb-4">Company</h3>
            <ul className="space-y-3">
              <li><a href="#" className="text-neutral-400 hover:text-white">About Us</a></li>
              <li><a href="#" className="text-neutral-400 hover:text-white">Careers</a></li>
              <li><a href="#" className="text-neutral-400 hover:text-white">Contact Us</a></li>
              <li><a href="#" className="text-neutral-400 hover:text-white">Privacy Policy</a></li>
              <li><a href="#" className="text-neutral-400 hover:text-white">Terms of Service</a></li>
            </ul>
          </div>
        </div>
        
        <div className="mt-12 pt-8 border-t border-neutral-800 text-neutral-400 text-sm flex flex-col md:flex-row justify-between items-center">
          <p>© {new Date().getFullYear()} SoftwareReviews. All rights reserved.</p>
          <div className="mt-4 md:mt-0 flex gap-6">
            <a href="#" className="hover:text-white">Privacy Policy</a>
            <a href="#" className="hover:text-white">Terms of Service</a>
            <a href="#" className="hover:text-white">Cookie Policy</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
