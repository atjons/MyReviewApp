import React from 'react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { CloseIcon, StackIcon } from '@/components/ui/icons';
import { useAuth } from '@/hooks/use-auth';

interface MobileMenuProps {
  isOpen: boolean;
  onClose: () => void;
}

export function MobileMenu({ isOpen, onClose }: MobileMenuProps) {
  const { user, logoutMutation } = useAuth();
  
  const handleLogout = () => {
    logoutMutation.mutate();
    onClose();
  };
  
  if (!isOpen) return null;
  
  return (
    <div className="md:hidden bg-white fixed inset-0 z-50 flex flex-col transform transition-transform duration-300 ease-in-out">
      <div className="px-4 py-5 flex items-center justify-between border-b border-neutral-200">
        <Link href="/" onClick={onClose}>
          <div className="flex items-center gap-2 cursor-pointer">
            <div className="h-8 w-8 rounded-md bg-primary text-white flex items-center justify-center">
              <StackIcon className="h-5 w-5" />
            </div>
            <span className="text-xl font-bold">SoftwareReviews</span>
          </div>
        </Link>
        <Button 
          variant="ghost" 
          size="icon" 
          onClick={onClose} 
          className="focus:outline-none"
        >
          <CloseIcon className="h-6 w-6" />
        </Button>
      </div>
      
      <div className="p-4 overflow-y-auto flex-1">
        <nav className="space-y-3">
          <Link href="/categories" onClick={onClose}>
            <Button variant="ghost" className="w-full justify-start">Categories</Button>
          </Link>
          <Link href="/compare" onClick={onClose}>
            <Button variant="ghost" className="w-full justify-start">Compare</Button>
          </Link>
          <Link href="/review" onClick={onClose}>
            <Button variant="ghost" className="w-full justify-start">Write a Review</Button>
          </Link>
          
          {user && (
            <>
              <div className="pt-4 border-t border-neutral-100">
                <h3 className="text-sm font-medium text-neutral-500 mb-2">My Account</h3>
                <Link href="/profile" onClick={onClose}>
                  <Button variant="ghost" className="w-full justify-start">Profile</Button>
                </Link>
                <Link href="/my-reviews" onClick={onClose}>
                  <Button variant="ghost" className="w-full justify-start">My Reviews</Button>
                </Link>
              </div>
            </>
          )}
        </nav>
      </div>
      
      <div className="p-4 border-t border-neutral-200">
        {user ? (
          <Button 
            variant="destructive" 
            className="w-full" 
            onClick={handleLogout}
          >
            Logout
          </Button>
        ) : (
          <Link href="/auth" onClick={onClose}>
            <Button className="w-full">
              Sign In
            </Button>
          </Link>
        )}
      </div>
    </div>
  );
}
