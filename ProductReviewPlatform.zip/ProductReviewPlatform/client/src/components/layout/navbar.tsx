import React, { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { StackIcon, SearchIcon, MenuIcon } from '@/components/ui/icons';
import { MobileMenu } from './mobile-menu';
import { useAuth } from '@/hooks/use-auth';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

export function Navbar() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();
  
  const handleLogout = () => {
    logoutMutation.mutate();
  };

  return (
    <>
      <header className="sticky top-0 z-50 w-full border-b border-neutral-200 bg-white">
        <div className="mx-auto flex max-w-7xl items-center justify-between p-4">
          {/* Logo */}
          <Link href="/">
            <div className="flex items-center gap-2 cursor-pointer">
              <div className="h-8 w-8 rounded-md bg-primary text-white flex items-center justify-center">
                <StackIcon className="h-5 w-5" />
              </div>
              <span className="text-xl font-bold">SoftwareReviews</span>
            </div>
          </Link>
          
          {/* Search Bar (Desktop) */}
          <div className="hidden md:flex relative flex-1 mx-8 max-w-md">
            <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
              <SearchIcon className="h-4 w-4 text-neutral-400" />
            </div>
            <Input 
              type="search" 
              placeholder="Search for software..." 
              className="pl-10"
            />
          </div>
          
          {/* Navigation (Desktop) */}
          <nav className="hidden md:flex items-center gap-1">
            <Link href="/categories">
              <Button variant="ghost" size="sm" className={location === '/categories' ? 'bg-neutral-100' : ''}>
                Categories
              </Button>
            </Link>
            <Link href="/compare">
              <Button variant="ghost" size="sm" className={location === '/compare' ? 'bg-neutral-100' : ''}>
                Compare
              </Button>
            </Link>
            <Link href="/review">
              <Button variant="ghost" size="sm" className={location === '/review' ? 'bg-neutral-100' : ''}>
                Write a Review
              </Button>
            </Link>
            
            {user ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="ml-2 rounded-full">
                    <Avatar className="h-8 w-8">
                      <AvatarImage src={user.avatar} alt={user.username} />
                      <AvatarFallback>{user.username.substring(0, 2).toUpperCase()}</AvatarFallback>
                    </Avatar>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuLabel>My Account</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem>
                    <Link href="/profile">Profile</Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem>
                    <Link href="/my-reviews">My Reviews</Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleLogout}>
                    Logout
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <Link href="/auth">
                <Button size="sm" className="ml-2">
                  Sign In
                </Button>
              </Link>
            )}
          </nav>
          
          {/* Mobile Menu Button */}
          <Button 
            variant="ghost" 
            size="icon"
            className="md:hidden" 
            onClick={() => setIsMobileMenuOpen(true)}
          >
            <MenuIcon className="h-6 w-6" />
          </Button>
        </div>
        
        {/* Search Bar (Mobile) */}
        <div className="p-4 md:hidden">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
              <SearchIcon className="h-4 w-4 text-neutral-400" />
            </div>
            <Input 
              type="search" 
              placeholder="Search for software..." 
              className="pl-10 w-full"
            />
          </div>
        </div>
      </header>
      
      {/* Mobile Menu */}
      <MobileMenu 
        isOpen={isMobileMenuOpen} 
        onClose={() => setIsMobileMenuOpen(false)} 
      />
    </>
  );
}
