import React, { useState } from 'react';
import { useLocation } from 'wouter';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

interface ComparisonFormProps {
  products: any[];
}

export function ComparisonForm({ products }: ComparisonFormProps) {
  const [, setLocation] = useLocation();
  const [selectedProducts, setSelectedProducts] = useState<string[]>(['', '', '']);

  const handleProductChange = (value: string, index: number) => {
    const newSelectedProducts = [...selectedProducts];
    newSelectedProducts[index] = value;
    setSelectedProducts(newSelectedProducts);
  };

  const handleCompare = () => {
    // Filter out empty selections
    const validProductIds = selectedProducts.filter(id => id);
    
    if (validProductIds.length < 2) {
      alert('Please select at least two products to compare');
      return;
    }
    
    const queryString = `?ids=${validProductIds.join(',')}`;
    setLocation(`/compare${queryString}`);
  };

  return (
    <div className="space-y-4">
      <div>
        <Label htmlFor="product1" className="block text-sm font-medium text-neutral-700 mb-1">
          Product #1
        </Label>
        <Select value={selectedProducts[0]} onValueChange={(value) => handleProductChange(value, 0)}>
          <SelectTrigger id="product1" className="w-full">
            <SelectValue placeholder="Select a product" />
          </SelectTrigger>
          <SelectContent>
            <SelectGroup>
              {products.map((product) => (
                <SelectItem key={product.id} value={product.id.toString()}>
                  {product.name}
                </SelectItem>
              ))}
            </SelectGroup>
          </SelectContent>
        </Select>
      </div>
      
      <div>
        <Label htmlFor="product2" className="block text-sm font-medium text-neutral-700 mb-1">
          Product #2
        </Label>
        <Select value={selectedProducts[1]} onValueChange={(value) => handleProductChange(value, 1)}>
          <SelectTrigger id="product2" className="w-full">
            <SelectValue placeholder="Select a product" />
          </SelectTrigger>
          <SelectContent>
            <SelectGroup>
              {products.map((product) => (
                <SelectItem key={product.id} value={product.id.toString()}>
                  {product.name}
                </SelectItem>
              ))}
            </SelectGroup>
          </SelectContent>
        </Select>
      </div>
      
      <div>
        <Label htmlFor="product3" className="block text-sm font-medium text-neutral-700 mb-1">
          Product #3 (optional)
        </Label>
        <Select value={selectedProducts[2]} onValueChange={(value) => handleProductChange(value, 2)}>
          <SelectTrigger id="product3" className="w-full">
            <SelectValue placeholder="Select a product" />
          </SelectTrigger>
          <SelectContent>
            <SelectGroup>
              {products.map((product) => (
                <SelectItem key={product.id} value={product.id.toString()}>
                  {product.name}
                </SelectItem>
              ))}
            </SelectGroup>
          </SelectContent>
        </Select>
      </div>
      
      <Button 
        type="button" 
        className="w-full" 
        onClick={handleCompare}
      >
        Compare Now
      </Button>
    </div>
  );
}
