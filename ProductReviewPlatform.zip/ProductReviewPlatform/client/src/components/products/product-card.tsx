import React from 'react';
import { Link } from 'wouter';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { StarRating } from '@/components/ui/star-rating';
import { useQuery } from '@tanstack/react-query';
import { Product, ProductFeature } from '@shared/schema';

interface ProductCardProps {
  product: Product;
}

export function ProductCard({ product }: ProductCardProps) {
  // Fetch category and features
  const { data: category } = useQuery({
    queryKey: ['/api/categories', product.categoryId],
    queryFn: () => fetch(`/api/categories/${product.categoryId}`).then(res => res.json()),
    enabled: !!product.categoryId,
  });

  const { data: features } = useQuery<ProductFeature[]>({
    queryKey: ['/api/products', product.id, 'features'],
    enabled: !!product.id,
  });

  return (
    <Card className="bg-white border border-neutral-200 rounded-lg shadow overflow-hidden transition-all hover:shadow-md group h-full flex flex-col">
      <div className="p-6 flex flex-col h-full">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center">
            <img 
              src={product.logo || `https://ui-avatars.com/api/?name=${product.name}&background=random`} 
              alt={`${product.name} logo`} 
              className="w-12 h-12 rounded-md object-cover"
            />
            <div className="ml-3">
              <h3 className="text-lg font-medium text-neutral-900">{product.name}</h3>
              {category && (
                <Badge variant="category" className="text-xs font-medium">
                  {category.name}
                </Badge>
              )}
            </div>
          </div>
          <div className="flex flex-col items-end">
            <StarRating rating={product.avgRating} showValue={true} />
            <span className="text-xs text-neutral-500">({product.reviewCount} reviews)</span>
          </div>
        </div>
        
        <p className="text-sm text-neutral-600 mb-6 line-clamp-3">
          {product.description}
        </p>
        
        <div className="flex flex-wrap gap-2 mb-6">
          {features?.slice(0, 3).map((feature) => (
            <Badge key={feature.id} variant="feature" className="text-xs font-medium">
              {feature.feature}
            </Badge>
          ))}
        </div>
        
        <div className="border-t border-neutral-200 pt-4 mt-auto">
          <div className="flex justify-between items-center">
            <Link href={`/products/${product.slug}`}>
              <span className="text-sm font-medium text-primary-600 hover:text-primary-700 group-hover:underline">
                View details
              </span>
            </Link>
            <Link href={`/compare?ids=${product.id}`}>
              <span className="text-sm font-medium text-primary-600 hover:text-primary-700 group-hover:underline">
                Compare
              </span>
            </Link>
          </div>
        </div>
      </div>
    </Card>
  );
}
