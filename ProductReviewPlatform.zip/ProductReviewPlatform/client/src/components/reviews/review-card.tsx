import React from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { StarRating } from '@/components/ui/star-rating';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';

interface ReviewCardProps {
  review: any;
}

export function ReviewCard({ review }: ReviewCardProps) {
  // Format date to readable string
  const getFormattedDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  return (
    <Card className="bg-white border border-neutral-200 rounded-lg shadow overflow-hidden transition-all hover:shadow-md">
      <div className="p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center">
            <Avatar className="h-10 w-10">
              <AvatarImage src={review.user?.avatar} alt={review.user?.fullName || review.user?.username} />
              <AvatarFallback>
                {(review.user?.fullName || review.user?.username || 'User')
                  .split(' ')
                  .map((n: string) => n[0])
                  .join('')
                  .toUpperCase()
                  .substring(0, 2)}
              </AvatarFallback>
            </Avatar>
            <div className="ml-3">
              <h3 className="text-sm font-medium text-neutral-900">
                {review.user?.fullName || review.user?.username}
              </h3>
              <p className="text-xs text-neutral-500">{review.user?.title || 'User'}</p>
            </div>
          </div>
          <StarRating rating={review.rating} />
        </div>
        
        <div className="mb-4">
          <div className="flex items-center mb-2">
            <img 
              src={review.product?.logo || `https://ui-avatars.com/api/?name=${review.product?.name}&background=random`}
              alt={`${review.product?.name} logo`} 
              className="h-8 w-8 rounded-md"
            />
            <h4 className="ml-2 text-base font-medium text-neutral-900">{review.product?.name}</h4>
          </div>
          
          <h5 className="text-lg font-semibold text-neutral-900 mb-2">
            "{review.title}"
          </h5>
          
          <p className="text-sm text-neutral-600 mb-4">
            {review.content}
          </p>
          
          {review.pros && review.pros.length > 0 && (
            <div className="flex flex-wrap gap-2 mb-2">
              {review.pros.map((pro: string, index: number) => (
                <Badge key={`pro-${index}`} variant="pros" className="text-xs font-medium">
                  Pros: {pro}
                </Badge>
              ))}
            </div>
          )}
          
          {review.cons && review.cons.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {review.cons.map((con: string, index: number) => (
                <Badge key={`con-${index}`} variant="cons" className="text-xs font-medium">
                  Cons: {con}
                </Badge>
              ))}
            </div>
          )}
        </div>
        
        <div className="text-right text-xs text-neutral-500">
          <span>Reviewed: {getFormattedDate(review.createdAt)}</span>
        </div>
      </div>
    </Card>
  );
}
