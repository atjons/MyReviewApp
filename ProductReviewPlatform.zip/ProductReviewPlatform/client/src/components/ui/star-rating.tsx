import React from 'react';
import { StarIcon } from '@/components/ui/icons';
import { cn } from '@/lib/utils';

interface StarRatingProps {
  rating: number;
  size?: number;
  className?: string;
  showValue?: boolean;
  reviewCount?: number;
}

export function StarRating({ rating, size = 16, className, showValue = false, reviewCount }: StarRatingProps) {
  // Convert rating to nearest half star
  const roundedRating = Math.round(rating * 2) / 2;
  
  return (
    <div className={cn("flex items-center", className)}>
      <div className="flex text-amber-500 mr-1">
        {[1, 2, 3, 4, 5].map((star) => {
          if (star <= Math.floor(roundedRating)) {
            // Full star
            return <StarIcon key={star} size={size} filled={true} className="mr-0.5" />;
          } else if (star === Math.ceil(roundedRating) && !Number.isInteger(roundedRating)) {
            // Half star (implemented with filled star and a pseudo-element to cover half)
            return (
              <div key={star} className="relative mr-0.5">
                <StarIcon size={size} filled={true} />
                <div className="absolute top-0 right-0 w-1/2 h-full bg-white"></div>
              </div>
            );
          } else {
            // Empty star
            return <StarIcon key={star} size={size} filled={false} className="mr-0.5" />;
          }
        })}
      </div>
      
      {showValue && (
        <span className="ml-1 text-lg font-medium">{rating.toFixed(1)}</span>
      )}
      
      {reviewCount !== undefined && (
        <span className="text-xs text-neutral-500 ml-1">({reviewCount} reviews)</span>
      )}
    </div>
  );
}
