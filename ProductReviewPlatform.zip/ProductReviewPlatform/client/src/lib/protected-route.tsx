import { useAuth } from "@/hooks/use-auth";
import { Loader2 } from "lucide-react";
import { Redirect, Route } from "wouter";
import { userRoles, UserRole } from "@shared/schema";

export function ProtectedRoute({
  path,
  component: Component,
  requiredRole,
}: {
  path: string;
  component: () => React.JSX.Element;
  requiredRole?: UserRole;
}) {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <Route path={path}>
        <div className="flex items-center justify-center min-h-screen">
          <Loader2 className="h-8 w-8 animate-spin text-border" />
        </div>
      </Route>
    );
  }

  if (!user) {
    return (
      <Route path={path}>
        <Redirect to="/auth" />
      </Route>
    );
  }

  // Role-based access check for admin routes
  if (requiredRole) {
    if (requiredRole === userRoles.SUPER_ADMIN && user.role !== userRoles.SUPER_ADMIN) {
      return (
        <Route path={path}>
          <div className="flex flex-col items-center justify-center min-h-screen">
            <h1 className="text-2xl font-bold text-red-500">Access Denied</h1>
            <p className="mt-2">You need Super Admin privileges to access this page.</p>
          </div>
        </Route>
      );
    }

    if (
      requiredRole === userRoles.PRODUCT_ADMIN && 
      user.role !== userRoles.PRODUCT_ADMIN && 
      user.role !== userRoles.SUPER_ADMIN
    ) {
      return (
        <Route path={path}>
          <div className="flex flex-col items-center justify-center min-h-screen">
            <h1 className="text-2xl font-bold text-red-500">Access Denied</h1>
            <p className="mt-2">You need Product Admin privileges to access this page.</p>
          </div>
        </Route>
      );
    }
  }

  return <Route path={path} component={Component} />;
}
