import React from 'react';
import { Link, useRoute } from 'wouter';
import { Navbar } from '@/components/layout/navbar';
import { Footer } from '@/components/layout/footer';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { ArrowRightIcon } from '@/components/ui/icons';
import { getCategoryIcon } from '@/components/ui/icons';
import { useQuery } from '@tanstack/react-query';
import { Skeleton } from '@/components/ui/skeleton';
import { ProductCard } from '@/components/products/product-card';
import { Category, Product } from '@shared/schema';

export default function CategoriesPage() {
  const [, params] = useRoute('/categories/:slug');
  const slug = params?.slug;
  
  // Fetch all categories
  const { data: categories, isLoading: isLoadingCategories } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
  });
  
  // Fetch specific category if slug is provided
  const { data: category, isLoading: isLoadingCategory } = useQuery<Category>({
    queryKey: [`/api/categories/${slug}`],
    enabled: !!slug,
  });
  
  // Fetch products in the category if slug is provided
  const { data: products, isLoading: isLoadingProducts } = useQuery<Product[]>({
    queryKey: ['/api/products', { categoryId: category?.id }],
    enabled: !!category?.id,
  });
  
  const isSpecificCategory = !!slug;

  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-grow py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {isSpecificCategory ? (
            <>
              {isLoadingCategory ? (
                <CategoryDetailsSkeleton />
              ) : !category ? (
                <div className="text-center py-16">
                  <h2 className="text-2xl font-bold">Category not found</h2>
                  <p className="text-neutral-600 mt-2 mb-6">The category you're looking for doesn't exist or has been removed.</p>
                  <Link href="/categories">
                    <Button>View All Categories</Button>
                  </Link>
                </div>
              ) : (
                <>
                  <div className="mb-10 text-center md:text-left">
                    <div className="inline-flex items-center justify-center w-16 h-16 bg-primary-100 text-primary-600 rounded-lg mb-4">
                      {getCategoryIcon(category.icon, 32)}
                    </div>
                    <h1 className="text-3xl font-bold text-neutral-900 mb-2">{category.name}</h1>
                    {category.description && (
                      <p className="text-lg text-neutral-600 max-w-3xl">{category.description}</p>
                    )}
                    <div className="mt-4 text-neutral-500">
                      {category.productCount} products in this category
                    </div>
                  </div>
                  
                  <div className="border-b border-neutral-200 pb-6 mb-8">
                    <h2 className="text-2xl font-bold text-neutral-900 mb-6">Top Products in {category.name}</h2>
                    
                    {isLoadingProducts ? (
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                        {Array.from({ length: 3 }).map((_, i) => (
                          <div key={i} className="border border-neutral-200 rounded-lg p-6 animate-pulse">
                            <div className="flex items-center mb-4">
                              <Skeleton className="h-12 w-12 rounded-md" />
                              <div className="ml-3">
                                <Skeleton className="h-5 w-28 mb-1" />
                                <Skeleton className="h-4 w-20" />
                              </div>
                            </div>
                            <Skeleton className="h-4 w-full mb-2" />
                            <Skeleton className="h-4 w-full mb-2" />
                            <Skeleton className="h-4 w-3/4 mb-4" />
                            <div className="flex gap-2 mb-4">
                              <Skeleton className="h-6 w-16 rounded-full" />
                              <Skeleton className="h-6 w-20 rounded-full" />
                              <Skeleton className="h-6 w-24 rounded-full" />
                            </div>
                            <Skeleton className="h-10 w-full" />
                          </div>
                        ))}
                      </div>
                    ) : products?.length === 0 ? (
                      <div className="text-center py-16 bg-neutral-50 rounded-lg">
                        <h3 className="text-lg font-medium text-neutral-900 mb-2">No products in this category yet</h3>
                        <p className="text-neutral-600">Check back later for new additions.</p>
                      </div>
                    ) : (
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                        {products?.map(product => (
                          <ProductCard key={product.id} product={product} />
                        ))}
                      </div>
                    )}
                  </div>
                  
                  <div className="text-center mt-8 mb-4">
                    <Link href="/categories">
                      <Button variant="outline" className="gap-2">
                        <ArrowRightIcon className="h-4 w-4 rotate-180" />
                        Back to all categories
                      </Button>
                    </Link>
                  </div>
                </>
              )}
            </>
          ) : (
            <>
              <div className="text-center mb-12">
                <h1 className="text-3xl font-bold text-neutral-900 mb-4">Software Categories</h1>
                <p className="text-lg text-neutral-600 max-w-3xl mx-auto">
                  Browse our comprehensive collection of software categories to find the right tools for your business needs
                </p>
              </div>
              
              {isLoadingCategories ? (
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                  {Array.from({ length: 8 }).map((_, i) => (
                    <div key={i} className="bg-neutral-50 border border-neutral-200 rounded-lg p-6 animate-pulse">
                      <div className="w-12 h-12 bg-neutral-200 rounded-lg mb-4 mx-auto"></div>
                      <Skeleton className="h-6 w-3/4 mx-auto mb-2" />
                      <Skeleton className="h-4 w-1/2 mx-auto mb-4" />
                      <Skeleton className="h-5 w-1/3 mx-auto" />
                    </div>
                  ))}
                </div>
              ) : (
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                  {categories?.map((category) => (
                    <Link key={category.id} href={`/categories/${category.slug}`}>
                      <Card className="bg-neutral-50 border border-neutral-200 rounded-lg p-6 flex flex-col items-center text-center transition-all hover:shadow-md hover:border-primary-300 h-full">
                        <div className="w-12 h-12 bg-primary-100 text-primary-600 rounded-lg flex items-center justify-center mb-4">
                          {getCategoryIcon(category.icon, 24)}
                        </div>
                        <h3 className="text-lg font-medium text-neutral-900 mb-2">{category.name}</h3>
                        <p className="text-sm text-neutral-600 mb-4">{category.productCount} products</p>
                        <span className="text-sm font-medium text-primary-600 group-hover:text-primary-700 flex items-center mt-auto">
                          Browse tools
                          <ArrowRightIcon className="ml-1 h-3.5 w-3.5 transition-transform group-hover:translate-x-1" />
                        </span>
                      </Card>
                    </Link>
                  ))}
                </div>
              )}
            </>
          )}
        </div>
      </main>
      <Footer />
    </div>
  );
}

function CategoryDetailsSkeleton() {
  return (
    <div className="animate-pulse">
      <div className="mb-10 text-center md:text-left">
        <div className="inline-flex items-center justify-center w-16 h-16 bg-neutral-200 rounded-lg mb-4"></div>
        <Skeleton className="h-8 w-64 mb-2 mx-auto md:mx-0" />
        <Skeleton className="h-6 w-full max-w-3xl mb-2 mx-auto md:mx-0" />
        <Skeleton className="h-5 w-40 mt-4 mx-auto md:mx-0" />
      </div>
      
      <div className="border-b border-neutral-200 pb-6 mb-8">
        <Skeleton className="h-8 w-72 mb-6" />
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {Array.from({ length: 3 }).map((_, i) => (
            <div key={i} className="border border-neutral-200 rounded-lg p-6">
              <div className="flex items-center mb-4">
                <Skeleton className="h-12 w-12 rounded-md" />
                <div className="ml-3">
                  <Skeleton className="h-5 w-28 mb-1" />
                  <Skeleton className="h-4 w-20" />
                </div>
              </div>
              <Skeleton className="h-4 w-full mb-2" />
              <Skeleton className="h-4 w-full mb-2" />
              <Skeleton className="h-4 w-3/4 mb-4" />
              <div className="flex gap-2 mb-4">
                <Skeleton className="h-6 w-16 rounded-full" />
                <Skeleton className="h-6 w-20 rounded-full" />
                <Skeleton className="h-6 w-24 rounded-full" />
              </div>
              <Skeleton className="h-10 w-full" />
            </div>
          ))}
        </div>
      </div>
      
      <div className="text-center mt-8 mb-4">
        <Skeleton className="h-10 w-40 mx-auto" />
      </div>
    </div>
  );
}
