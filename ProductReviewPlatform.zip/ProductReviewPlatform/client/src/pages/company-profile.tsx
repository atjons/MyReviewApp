import React, { useState } from 'react';
import { Link, useRoute } from 'wouter';
import { Navbar } from '@/components/layout/navbar';
import { Footer } from '@/components/layout/footer';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { StarRating } from '@/components/ui/star-rating';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { useQuery } from '@tanstack/react-query';
import { ArrowRightIcon } from '@/components/ui/icons';

export default function CompanyProfile() {
  const [, params] = useRoute('/companies/:slug');
  const slug = params?.slug || 'salesforce'; // Fallback for demo purposes
  const [activeProfileTab, setActiveProfileTab] = useState<string>("all");
  const [activeReviewTab, setActiveReviewTab] = useState<string>("all");
  const [sortBy, setSortBy] = useState("popularity");
  const [searchQuery, setSearchQuery] = useState("");
  
  // Fetch company data
  const { data: company, isLoading: isLoadingCompany } = useQuery({
    queryKey: [`/api/companies/${slug}`],
    enabled: !!slug,
  });
  
  // Fetch company products
  const { data: products, isLoading: isLoadingProducts } = useQuery({
    queryKey: ['/api/companies/products', { company: slug }],
    enabled: !!slug,
  });
  
  // Fetch company reviews
  const { data: reviews, isLoading: isLoadingReviews } = useQuery({
    queryKey: ['/api/companies/reviews', { company: slug }],
    enabled: !!slug,
  });
  
  // Mock data for demo
  const mockCompany = {
    id: 1,
    name: "Salesforce",
    slug: "salesforce",
    logo: "https://upload.wikimedia.org/wikipedia/commons/f/f9/Salesforce.com_logo.svg",
    description: "Salesforce is a customer relationship management solution that brings companies and customers together. It's one integrated CRM platform that gives all your departments — including marketing, sales, commerce, and service — a single, shared view of every customer.",
    website: "https://salesforce.com",
    categories: ["CRM", "Marketing Automation", "Sales"],
    avgRating: 4.4,
    reviewCount: 3125,
    founded: 1999,
    headquarters: "San Francisco, CA",
    size: "10,000+ employees",
    type: "Public (NYSE:CRM)",
    products: [
      {
        id: 1,
        name: "Salesforce Sales Cloud",
        slug: "salesforce-sales-cloud",
        description: "Drive sales productivity with the #1 CRM solution.",
        logo: "https://upload.wikimedia.org/wikipedia/commons/f/f9/Salesforce.com_logo.svg",
        avgRating: 4.5,
        reviewCount: 1820,
        category: "CRM"
      },
      {
        id: 2,
        name: "Salesforce Marketing Cloud",
        slug: "salesforce-marketing-cloud",
        description: "Build customer journeys and personalize experiences across channels.",
        logo: "https://upload.wikimedia.org/wikipedia/commons/f/f9/Salesforce.com_logo.svg",
        avgRating: 4.3,
        reviewCount: 875,
        category: "Marketing Automation"
      },
      {
        id: 3,
        name: "Salesforce Service Cloud",
        slug: "salesforce-service-cloud",
        description: "Transform customer service with the world's #1 service platform.",
        logo: "https://upload.wikimedia.org/wikipedia/commons/f/f9/Salesforce.com_logo.svg",
        avgRating: 4.4,
        reviewCount: 720,
        category: "Customer Service"
      },
      {
        id: 4,
        name: "Salesforce Commerce Cloud",
        slug: "salesforce-commerce-cloud",
        description: "Create seamless shopping experiences across all channels.",
        logo: "https://upload.wikimedia.org/wikipedia/commons/f/f9/Salesforce.com_logo.svg",
        avgRating: 4.2,
        reviewCount: 415,
        category: "E-commerce"
      },
      {
        id: 5,
        name: "Salesforce Platform",
        slug: "salesforce-platform",
        description: "Build apps fast with the world's most trusted enterprise cloud platform.",
        logo: "https://upload.wikimedia.org/wikipedia/commons/f/f9/Salesforce.com_logo.svg",
        avgRating: 4.5,
        reviewCount: 520,
        category: "App Development"
      },
    ],
    reviews: [
      {
        id: 1,
        user: {
          name: "James T.",
          title: "Marketing Director",
          company: "Medium Enterprise",
          avatar: null
        },
        title: "Best experience",
        content: "It makes it so easy to track all sales, any issues, fast visibility into how accounts are doing, what needs attention, etc. I couldn't imagine not having this capability anymore.",
        rating: 5,
        pros: ["Easy to use", "Full-feature", "Fast, reliable, available"],
        cons: ["Expensive", "Steep learning curve"],
        verified: true,
        date: "2023-05-12"
      },
      {
        id: 2,
        user: {
          name: "Sarah P.",
          title: "Sales Manager",
          company: "Large Enterprise",
          avatar: null
        },
        title: "Value doesn't seem to work for all",
        content: "While the platform is comprehensive, the value proposition doesn't seem to align with all business models. We've found that for our specific industry, we had to make significant customizations which proved costly and time-consuming.",
        rating: 3.5,
        pros: ["Comprehensive features", "Good integrations"],
        cons: ["Expensive", "Too complex for our needs"],
        verified: true,
        date: "2023-07-28"
      },
      {
        id: 3,
        user: {
          name: "Michael S.",
          title: "CTO",
          company: "Small Business",
          avatar: null
        },
        title: "Great for offline",
        content: "I like the mobile features and the extensive API. The offline capabilities are particularly useful for our field sales team who often work in areas with limited connectivity.",
        rating: 4,
        pros: ["Mobile features", "Offline capabilities"],
        cons: ["Price increases frequently"],
        verified: true,
        date: "2023-09-15"
      }
    ]
  };
  
  // Use mock data for rendering
  const displayCompany = company || mockCompany;
  const displayProducts = products || mockCompany.products;
  const displayReviews = reviews || mockCompany.reviews;
  
  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      
      {/* Company profile header */}
      <div className="bg-neutral-50 border-b border-neutral-200 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-start">
            <div className="flex-shrink-0 mb-4 md:mb-0 md:mr-6">
              <img
                src={displayCompany.logo}
                alt={`${displayCompany.name} logo`}
                className="w-24 h-24 object-contain"
              />
            </div>
            
            <div className="flex-grow">
              <div className="flex flex-col md:flex-row md:items-center justify-between">
                <div>
                  <h1 className="text-3xl font-bold mb-1">{displayCompany.name}</h1>
                  <div className="flex items-center flex-wrap gap-2">
                    <StarRating rating={displayCompany.avgRating} showValue />
                    <span className="text-neutral-500 text-sm">({displayCompany.reviewCount} reviews)</span>
                    {displayCompany.categories.map((category, index) => (
                      <Badge key={index} variant="category">{category}</Badge>
                    ))}
                  </div>
                </div>
                
                <div className="flex space-x-4 mt-4 md:mt-0">
                  <Button variant="ghost" className="flex items-center gap-2 text-red-500">
                    <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                      <path fillRule="evenodd" d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z" clipRule="evenodd" />
                    </svg>
                    <span className="sr-only md:not-sr-only">Favorite</span>
                  </Button>
                  
                  <Button variant="ghost" className="flex items-center gap-2 text-yellow-500">
                    <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                    </svg>
                    <span>4.4</span>
                  </Button>
                  
                  <Button variant="ghost" className="flex items-center gap-2 text-green-500">
                    <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                      <path fillRule="evenodd" d="M6.267 3.455a3.066 3.066 0 001.745-.723 3.066 3.066 0 013.976 0 3.066 3.066 0 001.745.723 3.066 3.066 0 012.812 2.812c.051.643.304 1.254.723 1.745a3.066 3.066 0 010 3.976 3.066 3.066 0 00-.723 1.745 3.066 3.066 0 01-2.812 2.812 3.066 3.066 0 00-1.745.723 3.066 3.066 0 01-3.976 0 3.066 3.066 0 00-1.745-.723 3.066 3.066 0 01-2.812-2.812 3.066 3.066 0 00-.723-1.745 3.066 3.066 0 010-3.976 3.066 3.066 0 00.723-1.745 3.066 3.066 0 012.812-2.812zm7.44 5.252a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                    </svg>
                    <span>Gartner Leader</span>
                  </Button>
                  
                  <Button variant="ghost" className="flex items-center gap-2 text-blue-500">
                    <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                      <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
                    </svg>
                    <span>{displayCompany.founded}</span>
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <main className="flex-grow bg-white py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row gap-8">
            {/* Sidebar */}
            <div className="w-full lg:w-64 flex-shrink-0">
              <Card className="sticky top-6">
                <CardContent className="p-4">
                  <h3 className="font-medium mb-3">Profile Type</h3>
                  <div className="space-y-2">
                    <div className="flex items-center">
                      <input type="radio" id="type-sales" name="profile-type" className="mr-2" defaultChecked />
                      <label htmlFor="type-sales" className="text-sm">Sales</label>
                    </div>
                    <div className="flex items-center">
                      <input type="radio" id="type-service" name="profile-type" className="mr-2" />
                      <label htmlFor="type-service" className="text-sm">Service</label>
                    </div>
                    <div className="flex items-center">
                      <input type="radio" id="type-product" name="profile-type" className="mr-2" />
                      <label htmlFor="type-product" className="text-sm">Product</label>
                    </div>
                  </div>
                  
                  <Separator className="my-4" />
                  
                  <div className="space-y-4">
                    <h3 className="font-medium">AI Agent Reviews</h3>
                    <Button variant="outline" size="sm" className="w-full text-xs">Show All Results</Button>
                  </div>
                  
                  <Separator className="my-4" />
                  
                  <div className="space-y-2">
                    <h3 className="font-medium mb-2">Business Function (Popular)</h3>
                    
                    <div className="space-y-1">
                      <div className="flex items-center">
                        <input type="checkbox" id="func-sales" className="mr-2" />
                        <label htmlFor="func-sales" className="text-sm">Sales</label>
                      </div>
                      <div className="flex items-center">
                        <input type="checkbox" id="func-finance" className="mr-2" />
                        <label htmlFor="func-finance" className="text-sm">Finance</label>
                      </div>
                      <div className="flex items-center">
                        <input type="checkbox" id="func-it" className="mr-2" />
                        <label htmlFor="func-it" className="text-sm">IT</label>
                      </div>
                      <div className="flex items-center">
                        <input type="checkbox" id="func-cs" className="mr-2" />
                        <label htmlFor="func-cs" className="text-sm">Customer Service</label>
                      </div>
                      <div className="flex items-center">
                        <input type="checkbox" id="func-marketing" className="mr-2" />
                        <label htmlFor="func-marketing" className="text-sm">Marketing</label>
                      </div>
                    </div>
                  </div>
                  
                  <Separator className="my-4" />
                  
                  <div className="space-y-2">
                    <h3 className="font-medium mb-2">Categories</h3>
                    
                    <div className="space-y-1">
                      <div className="flex items-center">
                        <input type="checkbox" id="cat-crm" className="mr-2" />
                        <label htmlFor="cat-crm" className="text-sm">CRM</label>
                      </div>
                      <div className="flex items-center">
                        <input type="checkbox" id="cat-marketing" className="mr-2" />
                        <label htmlFor="cat-marketing" className="text-sm">Marketing Automation</label>
                      </div>
                      <div className="flex items-center">
                        <input type="checkbox" id="cat-sales" className="mr-2" />
                        <label htmlFor="cat-sales" className="text-sm">Sales Intelligence</label>
                      </div>
                      <div className="flex items-center">
                        <input type="checkbox" id="cat-cs" className="mr-2" />
                        <label htmlFor="cat-cs" className="text-sm">Customer Service</label>
                      </div>
                    </div>
                    
                    <Button variant="link" size="sm" className="text-xs px-0">See more categories</Button>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            {/* Main Content */}
            <div className="flex-1">
              <h2 className="text-2xl font-bold mb-6">All Profiles</h2>
              
              <div className="flex justify-between items-center mb-6">
                <div className="flex space-x-4">
                  <Tabs value={activeProfileTab} onValueChange={setActiveProfileTab} className="w-full">
                    <TabsList>
                      <TabsTrigger value="all">All</TabsTrigger>
                      <TabsTrigger value="sales">Sales</TabsTrigger>
                      <TabsTrigger value="service">Service</TabsTrigger>
                      <TabsTrigger value="product">Product</TabsTrigger>
                    </TabsList>
                  </Tabs>
                </div>
                
                <div className="flex items-center">
                  <span className="text-sm text-neutral-500 mr-2">Sort By: </span>
                  <select 
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value)}
                    className="border-none text-sm bg-transparent focus:ring-0"
                  >
                    <option value="popularity">Popularity</option>
                    <option value="rating">Rating</option>
                    <option value="name">Name (A-Z)</option>
                    <option value="reviews">Most Reviews</option>
                  </select>
                </div>
              </div>
              
              {/* Products Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {displayProducts.map((product) => (
                  <Card key={product.id} className="overflow-hidden hover:shadow-md transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex justify-between mb-4">
                        <div className="flex">
                          <img src={product.logo} alt={product.name} className="w-10 h-10 mr-3" />
                          <div>
                            <h3 className="font-medium">{product.name}</h3>
                            <div className="flex items-center mt-1">
                              <StarRating rating={product.avgRating} size={14} />
                              <span className="text-xs text-neutral-500 ml-2">({product.reviewCount} reviews)</span>
                            </div>
                          </div>
                        </div>
                        <Badge>{product.category}</Badge>
                      </div>
                      
                      <p className="text-sm text-neutral-600 mb-4 line-clamp-3">{product.description}</p>
                      
                      <div className="flex justify-between items-center mt-4">
                        <Link href={`/products/${product.slug}`}>
                          <Button variant="link" className="text-sm p-0 h-auto">View Product</Button>
                        </Link>
                        <Button variant="outline" size="sm">Compare</Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
              
              <Separator className="my-10" />
              
              {/* Product Description */}
              <div className="bg-neutral-50 border border-neutral-200 rounded-lg p-6 mb-10">
                <div className="flex items-center gap-3 mb-4">
                  <div className="p-2 bg-green-100 rounded-lg">
                    <svg className="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z" />
                    </svg>
                  </div>
                  <h3 className="text-lg font-semibold">Product Description</h3>
                </div>
                <p className="text-neutral-700 mb-4">{displayCompany.description}</p>
                <div className="flex justify-between items-center">
                  <p className="text-sm text-neutral-500">
                    <span className="font-medium">Founded:</span> {displayCompany.founded}
                  </p>
                  <Button variant="outline" size="sm">Visit Website</Button>
                </div>
              </div>
              
              {/* Reviews Section */}
              <div>
                <h2 className="text-2xl font-bold mb-6">Salesforce Reviews</h2>
                
                <div className="flex justify-between items-center mb-6">
                  <Tabs value={activeReviewTab} onValueChange={setActiveReviewTab} className="w-full">
                    <TabsList>
                      <TabsTrigger value="all">All Reviews</TabsTrigger>
                      <TabsTrigger value="featured">Featured</TabsTrigger>
                      <TabsTrigger value="positive">Positive Only</TabsTrigger>
                      <TabsTrigger value="critical">Critical Only</TabsTrigger>
                      <TabsTrigger value="media">Media</TabsTrigger>
                    </TabsList>
                  </Tabs>
                  
                  <div>
                    <select 
                      className="border-none text-sm bg-transparent focus:ring-0"
                      value="recent"
                    >
                      <option value="recent">Sort By: Most Recent</option>
                      <option value="helpful">Most Helpful</option>
                      <option value="rating-high">Highest Rating</option>
                      <option value="rating-low">Lowest Rating</option>
                    </select>
                  </div>
                </div>
                
                {/* Reviews List */}
                <div className="space-y-8">
                  {displayReviews.map((review) => (
                    <div key={review.id} className="border-b border-neutral-200 pb-8">
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center">
                          <Avatar className="h-10 w-10 mr-3">
                            <AvatarImage src={review.user.avatar || undefined} />
                            <AvatarFallback>
                              {review.user.name.split(' ').map(n => n[0]).join('').toUpperCase()}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <h4 className="font-medium">{review.user.name}</h4>
                            <p className="text-sm text-neutral-500">{review.user.title}, {review.user.company}</p>
                          </div>
                        </div>
                        <div className="flex flex-col items-end">
                          <StarRating rating={review.rating} size={16} />
                          <span className="text-xs text-neutral-500">{review.date}</span>
                        </div>
                      </div>
                      
                      <h3 className="text-lg font-semibold mb-2">"{review.title}"</h3>
                      <p className="text-neutral-700 mb-4">{review.content}</p>
                      
                      {review.pros && review.pros.length > 0 && (
                        <div className="mb-3">
                          <h5 className="text-sm font-semibold mb-1">What do you like best?</h5>
                          <div className="flex flex-wrap gap-2">
                            {review.pros.map((pro, i) => (
                              <Badge key={i} variant="pros" className="text-xs">{pro}</Badge>
                            ))}
                          </div>
                        </div>
                      )}
                      
                      {review.cons && review.cons.length > 0 && (
                        <div>
                          <h5 className="text-sm font-semibold mb-1">What do you dislike?</h5>
                          <div className="flex flex-wrap gap-2">
                            {review.cons.map((con, i) => (
                              <Badge key={i} variant="cons" className="text-xs">{con}</Badge>
                            ))}
                          </div>
                        </div>
                      )}
                      
                      <div className="mt-4 flex justify-end">
                        <Button variant="link" size="sm" className="text-sm">
                          Read More <ArrowRightIcon className="w-3 h-3 ml-1" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      
      {/* Additional Info Section */}
      <section className="bg-neutral-50 py-12 border-t border-neutral-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-2xl font-bold mb-8">About</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
            <div>
              <h3 className="text-lg font-semibold mb-4">Company</h3>
              <p className="text-neutral-700 mb-4">{displayCompany.description}</p>
              <Button variant="outline" size="sm">Visit Website</Button>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-4">Details</h3>
              <div className="space-y-3">
                <div className="flex text-sm">
                  <span className="text-neutral-500 w-32">Year Founded:</span>
                  <span>{displayCompany.founded}</span>
                </div>
                <div className="flex text-sm">
                  <span className="text-neutral-500 w-32">Headquarters:</span>
                  <span>{displayCompany.headquarters}</span>
                </div>
                <div className="flex text-sm">
                  <span className="text-neutral-500 w-32">Company Size:</span>
                  <span>{displayCompany.size}</span>
                </div>
                <div className="flex text-sm">
                  <span className="text-neutral-500 w-32">Company Type:</span>
                  <span>{displayCompany.type}</span>
                </div>
              </div>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-4">Social</h3>
              <div className="flex space-x-4">
                <a href="#" className="text-neutral-700 hover:text-primary-600">
                  <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path fillRule="evenodd" d="M12.315 2c2.43 0 2.784.013 3.808.06 1.064.049 1.791.218 2.427.465a4.902 4.902 0 011.772 1.153 4.902 4.902 0 011.153 1.772c.247.636.416 1.363.465 2.427.048 1.067.06 1.407.06 4.123v.08c0 2.643-.012 2.987-.06 4.043-.049 1.064-.218 1.791-.465 2.427a4.902 4.902 0 01-1.153 1.772 4.902 4.902 0 01-1.772 1.153c-.636.247-1.363.416-2.427.465-1.067.048-1.407.06-4.123.06h-.08c-2.643 0-2.987-.012-4.043-.06-1.064-.049-1.791-.218-2.427-.465a4.902 4.902 0 01-1.772-1.153 4.902 4.902 0 01-1.153-1.772c-.247-.636-.416-1.363-.465-2.427-.047-1.024-.06-1.379-.06-3.808v-.63c0-2.43.013-2.784.06-3.808.049-1.064.218-1.791.465-2.427a4.902 4.902 0 011.153-1.772A4.902 4.902 0 015.45 2.525c.636-.247 1.363-.416 2.427-.465C8.901 2.013 9.256 2 11.685 2h.63zm-.081 1.802h-.468c-2.456 0-2.784.011-3.807.058-.975.045-1.504.207-1.857.344-.467.182-.8.398-1.15.748-.35.35-.566.683-.748 1.15-.137.353-.3.882-.344 1.857-.047 1.023-.058 1.351-.058 3.807v.468c0 2.456.011 2.784.058 3.807.045.975.207 1.504.344 1.857.182.466.399.8.748 1.15.35.35.683.566 1.15.748.353.137.882.3 1.857.344 1.054.048 1.37.058 4.041.058h.08c2.597 0 2.917-.01 3.96-.058.976-.045 1.505-.207 1.858-.344.466-.182.8-.398 1.15-.748.35-.35.566-.683.748-1.15.137-.353.3-.882.344-1.857.048-1.055.058-1.37.058-4.041v-.08c0-2.597-.01-2.917-.058-3.96-.045-.976-.207-1.505-.344-1.858a3.097 3.097 0 00-.748-1.15 3.098 3.098 0 00-1.15-.748c-.353-.137-.882-.3-1.857-.344-1.023-.047-1.351-.058-3.807-.058zM12 6.865a5.135 5.135 0 110 10.27 5.135 5.135 0 010-10.27zm0 1.802a3.333 3.333 0 100 6.666 3.333 3.333 0 000-6.666zm5.338-3.205a1.2 1.2 0 110 2.4 1.2 1.2 0 010-2.4z" clipRule="evenodd" />
                  </svg>
                </a>
                <a href="#" className="text-neutral-700 hover:text-primary-600">
                  <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path d="M8.29 20.251c7.547 0 11.675-6.253 11.675-11.675 0-.178 0-.355-.012-.53A8.348 8.348 0 0022 5.92a8.19 8.19 0 01-2.357.646 4.118 4.118 0 001.804-2.27 8.224 8.224 0 01-2.605.996 4.107 4.107 0 00-6.993 3.743 11.65 11.65 0 01-8.457-4.287 4.106 4.106 0 001.27 5.477A4.072 4.072 0 012.8 9.713v.052a4.105 4.105 0 003.292 4.022 4.095 4.095 0 01-1.853.07 4.108 4.108 0 003.834 2.85A8.233 8.233 0 012 18.407a11.616 11.616 0 006.29 1.84" />
                  </svg>
                </a>
                <a href="#" className="text-neutral-700 hover:text-primary-600">
                  <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path fillRule="evenodd" d="M12 2C6.477 2 2 6.484 2 12.017c0 4.425 2.865 8.18 6.839 9.504.5.092.682-.217.682-.483 0-.237-.008-.868-.013-1.703-2.782.605-3.369-1.343-3.369-1.343-.454-1.158-1.11-1.466-1.11-1.466-.908-.62.069-.608.069-.608 1.003.07 1.531 1.032 1.531 1.032.892 1.53 2.341 1.088 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.113-4.555-4.951 0-1.093.39-1.988 1.029-2.688-.103-.253-.446-1.272.098-2.65 0 0 .84-.27 2.75 1.026A9.564 9.564 0 0112 6.844c.85.004 1.705.115 2.504.337 1.909-1.296 2.747-1.027 2.747-1.027.546 1.379.202 2.398.1 2.651.64.7 1.028 1.595 1.028 2.688 0 3.848-2.339 4.695-4.566 4.943.359.309.678.92.678 1.855 0 1.338-.012 2.419-.012 2.747 0 .268.18.58.688.482A10.019 10.019 0 0022 12.017C22 6.484 17.522 2 12 2z" clipRule="evenodd" />
                  </svg>
                </a>
                <a href="#" className="text-neutral-700 hover:text-primary-600">
                  <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path fillRule="evenodd" d="M19.812 5.418c.861.23 1.538.907 1.768 1.768C21.998 8.746 22 12 22 12s0 3.255-.418 4.814a2.504 2.504 0 0 1-1.768 1.768c-1.56.419-7.814.419-7.814.419s-6.255 0-7.814-.419a2.505 2.505 0 0 1-1.768-1.768C2 15.255 2 12 2 12s0-3.255.417-4.814a2.507 2.507 0 0 1 1.768-1.768C5.744 5 11.998 5 11.998 5s6.255 0 7.814.418ZM15.194 12 10 15V9l5.194 3Z" clipRule="evenodd" />
                  </svg>
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      <Footer />
    </div>
  );
}