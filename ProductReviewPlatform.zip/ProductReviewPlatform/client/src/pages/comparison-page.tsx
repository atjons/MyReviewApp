import React, { useState, useEffect } from 'react';
import { useLocation, Link } from 'wouter';
import { Navbar } from '@/components/layout/navbar';
import { Footer } from '@/components/layout/footer';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { StarRating } from '@/components/ui/star-rating';
import { useQuery } from '@tanstack/react-query';
import { Skeleton } from '@/components/ui/skeleton';
import { ComparisonForm } from '@/components/products/comparison-form';
import { CheckIcon, ArrowRightIcon } from '@/components/ui/icons';
import { Separator } from '@/components/ui/separator';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";

export default function ComparisonPage() {
  const [location] = useLocation();
  const [productIds, setProductIds] = useState<number[]>([]);
  
  // Parse product IDs from URL
  useEffect(() => {
    const params = new URLSearchParams(location.split('?')[1]);
    const idsParam = params.get('ids');
    if (idsParam) {
      const ids = idsParam.split(',').map(id => parseInt(id, 10)).filter(id => !isNaN(id));
      setProductIds(ids);
    }
  }, [location]);
  
  // Fetch all products for the comparison form
  const { data: allProducts } = useQuery({
    queryKey: ['/api/products'],
  });
  
  // Fetch comparison data
  const { data: comparedProducts, isLoading } = useQuery({
    queryKey: ['/api/comparison', { ids: productIds.join(',') }],
    enabled: productIds.length > 0,
  });
  
  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-grow py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <h1 className="text-3xl font-bold text-neutral-900 mb-4">Software Comparison</h1>
            <p className="text-lg text-neutral-600 max-w-3xl mx-auto">
              Compare software products side by side to find the best fit for your needs
            </p>
          </div>
          
          {/* Comparison Form */}
          <div className="bg-white rounded-lg border border-neutral-200 p-6 shadow mb-12 max-w-3xl mx-auto">
            <h2 className="text-xl font-semibold mb-6">Select Products to Compare</h2>
            
            {allProducts ? (
              <ComparisonForm products={allProducts} />
            ) : (
              <div className="space-y-4 animate-pulse">
                <Skeleton className="h-10 w-full" />
                <Skeleton className="h-10 w-full" />
                <Skeleton className="h-10 w-full" />
                <Skeleton className="h-10 w-full" />
              </div>
            )}
          </div>
          
          {/* Comparison Results */}
          {productIds.length > 0 && (
            <>
              {isLoading ? (
                <ComparisonSkeleton count={productIds.length} />
              ) : !comparedProducts || comparedProducts.length === 0 ? (
                <div className="text-center py-16 bg-neutral-50 rounded-lg border border-neutral-200">
                  <h2 className="text-xl font-semibold text-neutral-900 mb-2">No products found</h2>
                  <p className="text-neutral-600 mb-6">The products you're trying to compare don't exist or have been removed.</p>
                  <Link href="/products">
                    <Button>Browse Products</Button>
                  </Link>
                </div>
              ) : (
                <>
                  <div className="mb-4 overflow-x-auto pb-4">
                    <Table className="min-w-full border border-neutral-200 rounded-lg">
                      <TableHeader>
                        <TableRow className="bg-neutral-50">
                          <TableHead className="w-1/4">Features</TableHead>
                          {comparedProducts.map((product: any) => (
                            <TableHead key={product.id} className="text-center">
                              <div className="flex flex-col items-center">
                                <img
                                  src={product.logo || `https://ui-avatars.com/api/?name=${product.name}&background=random`}
                                  alt={`${product.name} logo`}
                                  className="w-12 h-12 rounded-md object-cover mb-2"
                                />
                                <span className="font-bold">{product.name}</span>
                                <StarRating rating={product.avgRating} size={14} />
                                <span className="text-xs text-neutral-500 mt-1">
                                  {product.reviewCount} reviews
                                </span>
                              </div>
                            </TableHead>
                          ))}
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        <TableRow>
                          <TableCell className="font-medium">Category</TableCell>
                          {comparedProducts.map((product: any) => (
                            <TableCell key={`${product.id}-category`} className="text-center">
                              <Badge variant="category">Category Name</Badge>
                            </TableCell>
                          ))}
                        </TableRow>
                        
                        <TableRow className="bg-neutral-50">
                          <TableCell className="font-medium">Description</TableCell>
                          {comparedProducts.map((product: any) => (
                            <TableCell key={`${product.id}-desc`} className="text-sm">
                              {product.description.length > 100 
                                ? `${product.description.substring(0, 100)}...` 
                                : product.description}
                            </TableCell>
                          ))}
                        </TableRow>
                        
                        <TableRow>
                          <TableCell className="font-medium">Rating</TableCell>
                          {comparedProducts.map((product: any) => (
                            <TableCell key={`${product.id}-rating`} className="text-center">
                              <div className="flex flex-col items-center">
                                <span className="text-2xl font-semibold">{product.avgRating.toFixed(1)}</span>
                                <StarRating rating={product.avgRating} />
                              </div>
                            </TableCell>
                          ))}
                        </TableRow>
                        
                        <TableRow className="bg-neutral-50">
                          <TableCell className="font-medium">Features</TableCell>
                          {comparedProducts.map((product: any) => (
                            <TableCell key={`${product.id}-features`}>
                              <div className="flex flex-wrap gap-1 justify-center">
                                {product.features?.map((feature: any) => (
                                  <Badge key={feature.id} variant="feature">
                                    {feature.feature}
                                  </Badge>
                                ))}
                                {(!product.features || product.features.length === 0) && 
                                  <span className="text-neutral-500 text-sm">No features listed</span>
                                }
                              </div>
                            </TableCell>
                          ))}
                        </TableRow>
                        
                        <TableRow>
                          <TableCell className="font-medium">Review Count</TableCell>
                          {comparedProducts.map((product: any) => (
                            <TableCell key={`${product.id}-count`} className="text-center">
                              {product.reviewCount} reviews
                            </TableCell>
                          ))}
                        </TableRow>
                        
                        <TableRow className="bg-neutral-50">
                          <TableCell className="font-medium">Actions</TableCell>
                          {comparedProducts.map((product: any) => (
                            <TableCell key={`${product.id}-actions`} className="text-center">
                              <Link href={`/products/${product.slug}`}>
                                <Button variant="outline" size="sm" className="mb-2 w-full">
                                  View Details
                                </Button>
                              </Link>
                              <Link href={`/review?productId=${product.id}`}>
                                <Button size="sm" className="w-full">
                                  Write Review
                                </Button>
                              </Link>
                            </TableCell>
                          ))}
                        </TableRow>
                      </TableBody>
                    </Table>
                  </div>
                  
                  <div className="bg-neutral-50 rounded-lg border border-neutral-200 p-6 mt-8">
                    <h3 className="text-lg font-semibold mb-4">Key Differences</h3>
                    
                    <div className="space-y-4">
                      {comparedProducts.map((product: any) => (
                        <div key={`${product.id}-diff`} className="flex items-start gap-3">
                          <div className="flex-shrink-0 mt-1">
                            <div className="w-6 h-6 rounded-full bg-primary-100 text-primary-600 flex items-center justify-center">
                              <CheckIcon className="h-3.5 w-3.5" />
                            </div>
                          </div>
                          <div>
                            <h4 className="font-medium text-neutral-900">{product.name}</h4>
                            <p className="text-sm text-neutral-600">
                              {product.description.substring(0, 150)}...
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                    
                    <Separator className="my-6" />
                    
                    <div className="text-center">
                      <p className="text-neutral-600 mb-4">
                        Not finding what you're looking for? Browse more software products.
                      </p>
                      <Link href="/products">
                        <Button variant="outline" className="gap-2">
                          View All Products
                          <ArrowRightIcon className="h-4 w-4" />
                        </Button>
                      </Link>
                    </div>
                  </div>
                </>
              )}
            </>
          )}
          
          {productIds.length === 0 && !isLoading && (
            <div className="text-center py-16 bg-neutral-50 rounded-lg border border-neutral-200">
              <h2 className="text-xl font-semibold text-neutral-900 mb-2">No products selected</h2>
              <p className="text-neutral-600 mb-6">
                Select at least two products to see a comparison.
              </p>
              <Link href="/products">
                <Button className="gap-2">
                  Browse Products
                  <ArrowRightIcon className="h-4 w-4" />
                </Button>
              </Link>
            </div>
          )}
        </div>
      </main>
      <Footer />
    </div>
  );
}

function ComparisonSkeleton({ count }: { count: number }) {
  return (
    <div className="animate-pulse">
      <div className="overflow-x-auto pb-4">
        <Table className="border border-neutral-200 rounded-lg">
          <TableHeader>
            <TableRow className="bg-neutral-50">
              <TableHead className="w-1/4">
                <Skeleton className="h-5 w-20" />
              </TableHead>
              {Array.from({ length: count }).map((_, i) => (
                <TableHead key={i} className="text-center">
                  <div className="flex flex-col items-center">
                    <Skeleton className="w-12 h-12 rounded-md mb-2" />
                    <Skeleton className="h-5 w-24" />
                    <Skeleton className="h-4 w-16 mt-1" />
                    <Skeleton className="h-3 w-12 mt-1" />
                  </div>
                </TableHead>
              ))}
            </TableRow>
          </TableHeader>
          <TableBody>
            {Array.from({ length: 6 }).map((_, rowIndex) => (
              <TableRow key={rowIndex} className={rowIndex % 2 === 1 ? 'bg-neutral-50' : ''}>
                <TableCell>
                  <Skeleton className="h-5 w-24" />
                </TableCell>
                {Array.from({ length: count }).map((_, cellIndex) => (
                  <TableCell key={cellIndex} className="text-center">
                    <Skeleton className="h-4 w-full mx-auto" />
                    {rowIndex === 2 && (
                      <Skeleton className="h-4 w-1/2 mx-auto mt-1" />
                    )}
                  </TableCell>
                ))}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
