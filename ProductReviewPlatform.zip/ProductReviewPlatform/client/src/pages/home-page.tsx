import React from 'react';
import { Navbar } from '@/components/layout/navbar';
import { Footer } from '@/components/layout/footer';
import { HeroSection } from '@/components/home/hero-section';
import { PopularCategories } from '@/components/home/popular-categories';
import { TopProducts } from '@/components/home/top-products';
import { ReviewProcess } from '@/components/home/review-process';
import { ComparisonTool } from '@/components/home/comparison-tool';
import { LatestReviews } from '@/components/home/latest-reviews';
import { CTASection } from '@/components/home/cta-section';

export default function HomePage() {
  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-grow">
        <HeroSection />
        <PopularCategories />
        <TopProducts />
        <ReviewProcess />
        <ComparisonTool />
        <LatestReviews />
        <CTASection />
      </main>
      <Footer />
    </div>
  );
}
