import React from 'react';
import { Link, useRoute } from 'wouter';
import { Navbar } from '@/components/layout/navbar';
import { Footer } from '@/components/layout/footer';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { StarRating } from '@/components/ui/star-rating';
import { useQuery } from '@tanstack/react-query';
import { ReviewCard } from '@/components/reviews/review-card';
import { Skeleton } from '@/components/ui/skeleton';
import { ArrowRightIcon, EditIcon } from '@/components/ui/icons';
import { Separator } from '@/components/ui/separator';
import { useAuth } from '@/hooks/use-auth';

export default function ProductDetails() {
  const [, params] = useRoute('/products/:slug');
  const slug = params?.slug;
  const { user } = useAuth();
  
  const { data: product, isLoading: isLoadingProduct } = useQuery({
    queryKey: [`/api/products/${slug}`],
    enabled: !!slug,
  });
  
  const { data: reviews, isLoading: isLoadingReviews } = useQuery({
    queryKey: ['/api/reviews', { productId: product?.id }],
    enabled: !!product?.id,
  });
  
  const { data: category } = useQuery({
    queryKey: ['/api/categories', product?.categoryId],
    enabled: !!product?.categoryId,
  });
  
  const hasReviewed = user ? reviews?.some((review: any) => review.userId === user.id) : false;

  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-grow py-8">
        {isLoadingProduct ? (
          <ProductDetailSkeleton />
        ) : !product ? (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center py-16">
            <h2 className="text-2xl font-bold">Product not found</h2>
            <p className="text-neutral-600 mt-2 mb-6">The product you're looking for doesn't exist or has been removed.</p>
            <Link href="/products">
              <Button>View All Products</Button>
            </Link>
          </div>
        ) : (
          <>
            {/* Product Header */}
            <div className="bg-neutral-50 py-8 border-b border-neutral-200">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="md:flex md:items-center md:justify-between">
                  <div className="flex items-center">
                    <img 
                      src={product.logo || `https://ui-avatars.com/api/?name=${product.name}&background=random`} 
                      alt={`${product.name} logo`}
                      className="w-16 h-16 rounded-lg object-cover mr-4"
                    />
                    <div>
                      <h1 className="text-3xl font-bold text-neutral-900">{product.name}</h1>
                      <div className="flex items-center mt-1">
                        {category && (
                          <Badge variant="category" className="mr-2">
                            {category.name}
                          </Badge>
                        )}
                        <StarRating rating={product.avgRating} showValue={true} reviewCount={product.reviewCount} />
                      </div>
                    </div>
                  </div>
                  
                  <div className="mt-4 md:mt-0 flex flex-wrap gap-3">
                    <Link href={`/compare?ids=${product.id}`}>
                      <Button variant="outline">Compare</Button>
                    </Link>
                    
                    {user && !hasReviewed && (
                      <Link href={`/review?productId=${product.id}`}>
                        <Button className="gap-2">
                          <EditIcon className="h-4 w-4" />
                          Write a Review
                        </Button>
                      </Link>
                    )}
                  </div>
                </div>
              </div>
            </div>
            
            {/* Product Content */}
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
                {/* Main Content */}
                <div className="lg:col-span-2">
                  <section className="mb-10">
                    <h2 className="text-2xl font-bold text-neutral-900 mb-4">Overview</h2>
                    <p className="text-neutral-700 whitespace-pre-line mb-6">{product.description}</p>
                    
                    {product.features && product.features.length > 0 && (
                      <div className="mt-6">
                        <h3 className="text-lg font-semibold mb-2">Key Features</h3>
                        <div className="flex flex-wrap gap-2">
                          {product.features.map((feature: any) => (
                            <Badge key={feature.id} variant="feature">
                              {feature.feature}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}
                  </section>
                  
                  <Separator className="my-8" />
                  
                  <section>
                    <div className="flex items-center justify-between mb-6">
                      <h2 className="text-2xl font-bold text-neutral-900">Reviews</h2>
                      {user && !hasReviewed && (
                        <Link href={`/review?productId=${product.id}`}>
                          <Button variant="outline" size="sm" className="gap-1">
                            <EditIcon className="h-3.5 w-3.5" />
                            Write a Review
                          </Button>
                        </Link>
                      )}
                    </div>
                    
                    {isLoadingReviews ? (
                      <div className="space-y-8">
                        {Array.from({ length: 3 }).map((_, i) => (
                          <div key={i} className="border border-neutral-200 rounded-lg p-4">
                            <div className="flex items-center mb-4">
                              <Skeleton className="h-10 w-10 rounded-full" />
                              <div className="ml-3">
                                <Skeleton className="h-4 w-24" />
                                <Skeleton className="h-3 w-16 mt-1" />
                              </div>
                            </div>
                            <Skeleton className="h-5 w-full mb-2" />
                            <Skeleton className="h-4 w-full mb-1" />
                            <Skeleton className="h-4 w-full mb-1" />
                            <Skeleton className="h-4 w-3/4" />
                          </div>
                        ))}
                      </div>
                    ) : reviews?.length === 0 ? (
                      <div className="text-center py-12 bg-neutral-50 rounded-lg border border-neutral-200">
                        <h3 className="text-lg font-medium text-neutral-900 mb-1">No reviews yet</h3>
                        <p className="text-neutral-600 mb-4">Be the first to review this product.</p>
                        {user && (
                          <Link href={`/review?productId=${product.id}`}>
                            <Button className="gap-2">
                              <EditIcon className="h-4 w-4" />
                              Write a Review
                            </Button>
                          </Link>
                        )}
                      </div>
                    ) : (
                      <div className="space-y-8">
                        {reviews?.map((review: any) => (
                          <ReviewCard key={review.id} review={review} />
                        ))}
                        
                        {reviews?.length > 3 && (
                          <div className="text-center mt-8">
                            <Button variant="outline" className="gap-2">
                              Load more reviews
                              <ArrowRightIcon className="h-4 w-4" />
                            </Button>
                          </div>
                        )}
                      </div>
                    )}
                  </section>
                </div>
                
                {/* Sidebar */}
                <div className="lg:col-span-1">
                  <div className="bg-white rounded-lg border border-neutral-200 p-6 sticky top-24">
                    <h3 className="text-lg font-semibold mb-4">Rating Breakdown</h3>
                    
                    {product.reviewCount > 0 ? (
                      <div className="space-y-4">
                        <div className="flex items-center mb-6">
                          <div className="text-5xl font-bold mr-4">{product.avgRating.toFixed(1)}</div>
                          <div>
                            <StarRating rating={product.avgRating} size={20} />
                            <div className="text-sm text-neutral-500 mt-1">{product.reviewCount} reviews</div>
                          </div>
                        </div>
                        
                        {/* Rating breakdown bars would go here */}
                        {[5, 4, 3, 2, 1].map((rating) => (
                          <div key={rating} className="flex items-center">
                            <div className="w-16 text-sm">{rating} stars</div>
                            <div className="flex-1 mx-3 bg-neutral-200 rounded-full h-2.5">
                              <div 
                                className="bg-amber-500 h-2.5 rounded-full" 
                                style={{ width: `${Math.random() * 100}%` }} 
                              ></div>
                            </div>
                            <div className="w-12 text-sm text-neutral-500">{Math.floor(Math.random() * 100)}%</div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-6">
                        <p className="text-neutral-600 mb-4">No ratings yet</p>
                        {user && (
                          <Link href={`/review?productId=${product.id}`}>
                            <Button variant="outline" className="gap-2" size="sm">
                              <EditIcon className="h-3.5 w-3.5" />
                              Be the first to review
                            </Button>
                          </Link>
                        )}
                      </div>
                    )}
                    
                    <Separator className="my-6" />
                    
                    <h3 className="text-lg font-semibold mb-4">Similar Products</h3>
                    
                    {/* We would fetch and display similar products here */}
                    {isLoadingProduct ? (
                      <div className="space-y-3">
                        {Array.from({ length: 3 }).map((_, i) => (
                          <div key={i} className="flex items-center p-2">
                            <Skeleton className="h-8 w-8 rounded-md" />
                            <div className="ml-2">
                              <Skeleton className="h-3.5 w-24" />
                              <Skeleton className="h-2.5 w-16 mt-1" />
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-4">
                        <p className="text-neutral-600 text-sm">Explore other products in this category</p>
                        <Link href={`/categories/${category?.slug}`}>
                          <Button variant="link" className="text-primary-600">
                            View category
                          </Button>
                        </Link>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </>
        )}
      </main>
      <Footer />
    </div>
  );
}

function ProductDetailSkeleton() {
  return (
    <div className="animate-pulse">
      <div className="bg-neutral-50 py-8 border-b border-neutral-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="md:flex md:items-center md:justify-between">
            <div className="flex items-center">
              <Skeleton className="w-16 h-16 rounded-lg mr-4" />
              <div>
                <Skeleton className="h-8 w-64 mb-2" />
                <Skeleton className="h-4 w-40" />
              </div>
            </div>
            <div className="mt-4 md:mt-0">
              <Skeleton className="h-10 w-32" />
            </div>
          </div>
        </div>
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          <div className="lg:col-span-2">
            <Skeleton className="h-8 w-40 mb-4" />
            <Skeleton className="h-5 w-full mb-2" />
            <Skeleton className="h-5 w-full mb-2" />
            <Skeleton className="h-5 w-full mb-2" />
            <Skeleton className="h-5 w-3/4" />
            
            <div className="my-8 border-t border-neutral-200 pt-8">
              <Skeleton className="h-8 w-40 mb-6" />
              <div className="space-y-8">
                {Array.from({ length: 3 }).map((_, i) => (
                  <div key={i} className="border border-neutral-200 rounded-lg p-4">
                    <div className="flex items-center mb-4">
                      <Skeleton className="h-10 w-10 rounded-full" />
                      <div className="ml-3">
                        <Skeleton className="h-4 w-24" />
                        <Skeleton className="h-3 w-16 mt-1" />
                      </div>
                    </div>
                    <Skeleton className="h-5 w-full mb-2" />
                    <Skeleton className="h-4 w-full mb-1" />
                    <Skeleton className="h-4 w-full mb-1" />
                    <Skeleton className="h-4 w-3/4" />
                  </div>
                ))}
              </div>
            </div>
          </div>
          
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg border border-neutral-200 p-6">
              <Skeleton className="h-6 w-40 mb-6" />
              <div className="flex items-center mb-6">
                <Skeleton className="h-16 w-16 mr-4" />
                <div>
                  <Skeleton className="h-5 w-24 mb-1" />
                  <Skeleton className="h-4 w-32" />
                </div>
              </div>
              
              {Array.from({ length: 5 }).map((_, i) => (
                <div key={i} className="flex items-center mb-2">
                  <Skeleton className="w-16 h-4" />
                  <Skeleton className="flex-1 mx-3 h-2.5 rounded-full" />
                  <Skeleton className="w-12 h-4" />
                </div>
              ))}
              
              <div className="my-6 border-t border-neutral-200 pt-6">
                <Skeleton className="h-6 w-40 mb-4" />
                <div className="space-y-3">
                  {Array.from({ length: 3 }).map((_, i) => (
                    <div key={i} className="flex items-center p-2">
                      <Skeleton className="h-8 w-8 rounded-md" />
                      <div className="ml-2">
                        <Skeleton className="h-3.5 w-24" />
                        <Skeleton className="h-2.5 w-16 mt-1" />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
