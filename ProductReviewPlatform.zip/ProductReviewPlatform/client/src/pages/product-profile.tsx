import React, { useState } from 'react';
import { Link, useRoute } from 'wouter';
import { Navbar } from '@/components/layout/navbar';
import { Footer } from '@/components/layout/footer';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { StarRating } from '@/components/ui/star-rating';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { useQuery } from '@tanstack/react-query';
import { ArrowRightIcon } from '@/components/ui/icons';
import { useAuth } from '@/hooks/use-auth';

export default function ProductProfile() {
  const [, params] = useRoute('/products/:slug');
  const slug = params?.slug || 'slack'; // Fallback for demo purposes
  const [activeTab, setActiveTab] = useState<string>("overview");
  const { user } = useAuth();
  
  // Fetch product data
  const { data: product, isLoading: isLoadingProduct } = useQuery({
    queryKey: [`/api/products/${slug}`],
    enabled: !!slug,
  });
  
  // Fetch reviews
  const { data: reviews, isLoading: isLoadingReviews } = useQuery({
    queryKey: ['/api/reviews', { productId: product?.id }],
    enabled: !!product?.id,
  });
  
  // Mock data for demo
  const mockProduct = {
    id: 1,
    name: "Slack",
    slug: "slack",
    logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/d/d5/Slack_icon_2019.svg/2048px-Slack_icon_2019.svg.png",
    description: "Slack is a messaging app for teams that connects people to the information they need. By bringing people together to work as one unified team, Slack transforms the way organizations communicate.",
    longDescription: `Slack is a cloud-based team collaboration platform that was launched in 2013 by Slack Technologies (now part of Salesforce). It's designed to facilitate communication and collaboration within organizations by providing a central place for messaging, tools, and files.

Key features include:
- Organized conversations in channels that can be divided by team, project, or topic
- Direct messaging for one-on-one conversations
- File sharing and integration with other services
- Voice and video calls
- Powerful search functionality
- Integrations with over 2,200 apps including Google Drive, Salesforce, and Asana
- Custom API for building integrations with internal tools

Slack aims to reduce the need for email and improve team productivity by centralizing communications and making information more accessible.`,
    website: "https://slack.com",
    category: "Team Communication",
    avgRating: 4.6,
    reviewCount: 1250,
    pricing: [
      {
        plan: "Free",
        price: "$0",
        features: ["10K searchable messages", "10 integrations", "1-to-1 video calls"]
      },
      {
        plan: "Pro",
        price: "$8.75/user/month",
        features: ["Unlimited message history", "Unlimited integrations", "Group video calls"]
      },
      {
        plan: "Business+",
        price: "$15/user/month",
        features: ["SAML SSO", "Data exports", "24/7 support", "99.99% uptime"]
      }
    ],
    features: [
      "Channel-based messaging", 
      "Voice and video calls", 
      "File sharing", 
      "App integrations",
      "Search functionality",
      "Custom emojis",
      "Threads",
      "Slash commands"
    ],
    alternatives: [
      {
        id: 2,
        name: "Microsoft Teams",
        logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/c/c9/Microsoft_Office_Teams_%282018%E2%80%93present%29.svg/1200px-Microsoft_Office_Teams_%282018%E2%80%93present%29.svg.png",
        avgRating: 4.2,
        reviewCount: 980
      },
      {
        id: 3,
        name: "Discord",
        logo: "https://assets-global.website-files.com/6257adef93867e50d84d30e2/636e0a69f118df70ad7828d4_icon_clyde_blurple_RGB.png",
        avgRating: 4.3,
        reviewCount: 756
      }
    ],
    screenshots: [
      {
        id: 1,
        src: "https://a.slack-edge.com/221d25b/marketing/img/homepage/e01801-desktop-campaign-hero-image-2x.png",
        alt: "Slack desktop interface"
      },
      {
        id: 2,
        src: "https://a.slack-edge.com/8b93edb/marketing/img/features/desktop-and-mobile/desktop-files-channels-3-2x.png",
        alt: "Slack channels and files"
      },
      {
        id: 3,
        src: "https://a.slack-edge.com/579ab16/marketing/img/features/desktop-and-mobile/desktop-dark-mode-3-2x.png",
        alt: "Slack dark mode"
      }
    ],
    reviews: [
      {
        id: 1,
        user: {
          name: "Alex Johnson",
          title: "Product Manager",
          company: "Tech Innovators",
          avatar: null
        },
        title: "Awesome team with exciting product!",
        content: "Slack has completely transformed how our team communicates. The channel organization makes it easy to keep conversations focused, and the integration with our other tools means we can get notifications and take actions without switching contexts. The search functionality is powerful and helps us find past conversations quickly.",
        rating: 5,
        pros: ["Easy to use", "Great integrations", "Excellent search", "Mobile app works well"],
        cons: ["Can get noisy with many channels", "Video calls could be better"],
        verified: true,
        date: "2023-01-28"
      },
      {
        id: 2,
        user: {
          name: "Taylor Smith",
          title: "Engineering Lead",
          company: "Innovative Solutions Inc.",
          avatar: null
        },
        title: "Great for remote teams",
        content: "As a distributed team, Slack has been essential for keeping everyone connected. The ability to create channels for different projects and teams helps us stay organized, and the integrations with our development tools make our workflows much smoother. It's become our virtual office.",
        rating: 4.5,
        pros: ["Excellent for remote work", "Good mobile experience", "Great integrations"],
        cons: ["Search could be improved", "Can be distracting"],
        verified: true,
        date: "2023-03-15"
      },
      {
        id: 3,
        user: {
          name: "Jamie Rivera",
          title: "Marketing Director",
          company: "Growth Ventures",
          avatar: null
        },
        title: "Indispensable communication tool",
        content: "Slack has become an essential part of our marketing team's workflow. The ability to share files and get immediate feedback has sped up our creative process. We also love how we can set up automated notifications for our marketing campaigns and analytics through integrations.",
        rating: 5,
        pros: ["Intuitive interface", "Powerful search", "Great file sharing"],
        cons: ["Can get overwhelming with too many channels"],
        verified: true,
        date: "2023-05-22"
      }
    ]
  };
  
  // Use mock data for rendering
  const displayProduct = product || mockProduct;
  const displayReviews = reviews || mockProduct.reviews;
  
  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      
      {/* Product header */}
      <div className="bg-white border-b border-neutral-200 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-6">
            <div className="flex items-center">
              <img 
                src={displayProduct.logo} 
                alt={`${displayProduct.name} logo`}
                className="w-16 h-16 object-contain rounded mr-4"
              />
              <div>
                <h1 className="text-3xl font-bold text-neutral-900">{displayProduct.name}</h1>
                <div className="flex items-center">
                  <StarRating rating={displayProduct.avgRating} showValue />
                  <span className="text-sm text-neutral-500 ml-2">({displayProduct.reviewCount} reviews)</span>
                </div>
              </div>
            </div>
            
            <div className="flex gap-3">
              <Button variant="outline">Visit Website</Button>
              <Button>Write a Review</Button>
            </div>
          </div>
          
          {/* Custom tab navigation instead of using Tabs component */}
          <div className="mt-8 border-b border-neutral-200">
            <div className="flex overflow-x-auto">
              <button 
                onClick={() => setActiveTab("overview")}
                className={`px-4 py-2 border-b-2 font-medium text-sm transition-colors ${
                  activeTab === "overview" 
                    ? "border-primary-600 text-primary-600" 
                    : "border-transparent text-neutral-500 hover:text-neutral-800"
                }`}
              >
                Overview
              </button>
              <button 
                onClick={() => setActiveTab("reviews")}
                className={`px-4 py-2 border-b-2 font-medium text-sm transition-colors ${
                  activeTab === "reviews" 
                    ? "border-primary-600 text-primary-600" 
                    : "border-transparent text-neutral-500 hover:text-neutral-800"
                }`}
              >
                Reviews
              </button>
              <button 
                onClick={() => setActiveTab("pricing")}
                className={`px-4 py-2 border-b-2 font-medium text-sm transition-colors ${
                  activeTab === "pricing" 
                    ? "border-primary-600 text-primary-600" 
                    : "border-transparent text-neutral-500 hover:text-neutral-800"
                }`}
              >
                Pricing
              </button>
              <button 
                onClick={() => setActiveTab("alternatives")}
                className={`px-4 py-2 border-b-2 font-medium text-sm transition-colors ${
                  activeTab === "alternatives" 
                    ? "border-primary-600 text-primary-600" 
                    : "border-transparent text-neutral-500 hover:text-neutral-800"
                }`}
              >
                Alternatives
              </button>
              <button 
                onClick={() => setActiveTab("questions")}
                className={`px-4 py-2 border-b-2 font-medium text-sm transition-colors ${
                  activeTab === "questions" 
                    ? "border-primary-600 text-primary-600" 
                    : "border-transparent text-neutral-500 hover:text-neutral-800"
                }`}
              >
                Q&A
              </button>
            </div>
          </div>
        </div>
      </div>
      
      <main className="flex-grow py-8 bg-neutral-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Use conditional rendering based on the active tab instead of TabsContent components */}
          {activeTab === "overview" && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {/* Main content */}
              <div className="md:col-span-2 space-y-8">
                {/* Product description */}
                <Card>
                  <CardContent className="p-6">
                    <h2 className="text-xl font-semibold mb-4">Product Description</h2>
                    <p className="text-neutral-700 whitespace-pre-line mb-4">{displayProduct.longDescription}</p>
                    
                    <div className="bg-neutral-50 border border-neutral-200 rounded-lg p-4 mt-6">
                      <h3 className="text-lg font-medium mb-3">Key Features</h3>
                      <ul className="grid grid-cols-1 md:grid-cols-2 gap-2">
                        {displayProduct?.features && Array.isArray(displayProduct.features) && displayProduct.features.map((feature, index) => (
                          <li key={index} className="flex items-center">
                            <svg className="w-5 h-5 text-green-600 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                            </svg>
                            <span>{typeof feature === 'object' && feature.feature ? feature.feature : feature}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </CardContent>
                </Card>
                
                {/* Screenshots */}
                <Card>
                  <CardContent className="p-6">
                    <h2 className="text-xl font-semibold mb-4">Screenshots</h2>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      {displayProduct?.screenshots && displayProduct.screenshots.length > 0 ? (
                        displayProduct.screenshots.map((screenshot) => (
                          <div key={screenshot.id} className="overflow-hidden rounded-lg border border-neutral-200">
                            <img 
                              src={screenshot.src}
                              alt={screenshot.alt}
                              className="w-full h-auto object-cover aspect-video"
                            />
                          </div>
                        ))
                      ) : (
                        <div className="col-span-3 py-8 text-center text-neutral-500">
                          No screenshots available
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
                
                {/* Reviews preview */}
                <Card>
                  <CardContent className="p-6">
                    <div className="flex justify-between items-center mb-4">
                      <h2 className="text-xl font-semibold">Reviews</h2>
                      <Button variant="link" onClick={() => setActiveTab("reviews")}>See all reviews</Button>
                    </div>
                    
                    <div className="space-y-6">
                      {displayReviews.slice(0, 2).map((review) => (
                        <div key={review.id} className="border-b border-neutral-200 pb-6 last:border-0 last:pb-0">
                          <div className="flex justify-between mb-2">
                            <div className="flex items-center">
                              <Avatar className="h-10 w-10 mr-3">
                                <AvatarImage src={review.user.avatar || undefined} />
                                <AvatarFallback>
                                  {review.user.name.split(' ').map(n => n[0]).join('').toUpperCase()}
                                </AvatarFallback>
                              </Avatar>
                              <div>
                                <h4 className="font-medium">{review.user.name}</h4>
                                <p className="text-sm text-neutral-500">{review.user.title}, {review.user.company}</p>
                              </div>
                            </div>
                            <StarRating rating={review.rating} size={16} />
                          </div>
                          
                          <h3 className="text-lg font-semibold mb-2">"{review.title}"</h3>
                          <p className="text-neutral-700 mb-3 line-clamp-3">{review.content}</p>
                          
                          <Button variant="link" className="text-sm p-0 h-auto">
                            Read full review <ArrowRightIcon className="ml-1 h-4 w-4" />
                          </Button>
                        </div>
                      ))}
                    </div>
                    
                    <div className="flex justify-center mt-6">
                      <Button onClick={() => setActiveTab("reviews")}>View All Reviews</Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
              
              {/* Sidebar */}
              <div className="space-y-6">
                {/* Quick info */}
                <Card>
                  <CardContent className="p-6">
                    <h3 className="text-lg font-medium mb-4">Quick Info</h3>
                    <div className="space-y-3">
                      <div className="flex justify-between text-sm">
                        <span className="text-neutral-500">Category</span>
                        <span className="font-medium">{displayProduct.category}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-neutral-500">Rating</span>
                        <span className="font-medium">{displayProduct.avgRating} / 5</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-neutral-500">Reviews</span>
                        <span className="font-medium">{displayProduct.reviewCount}</span>
                      </div>
                      {displayProduct?.pricing && displayProduct.pricing.length > 0 && (
                        <div className="flex justify-between text-sm">
                          <span className="text-neutral-500">Starting Price</span>
                          <span className="font-medium">{displayProduct.pricing[0].price}</span>
                        </div>
                      )}
                    </div>
                    
                    <Separator className="my-4" />
                    
                    <h3 className="text-lg font-medium mb-4">Rating Breakdown</h3>
                    
                    {/* Rating breakdown bars */}
                    <div className="space-y-2">
                      {[5, 4, 3, 2, 1].map((rating) => (
                        <div key={rating} className="flex items-center text-sm">
                          <div className="w-10">{rating} ★</div>
                          <div className="flex-1 mx-2 bg-neutral-200 rounded-full h-2">
                            <div 
                              className="bg-amber-500 h-2 rounded-full" 
                              style={{ width: `${Math.max(0, Math.min(100, (6 - rating) * 20 - (Math.random() * 15)))}%` }} 
                            ></div>
                          </div>
                          <div className="w-10 text-right">{Math.floor(Math.random() * 40 + 10)}%</div>
                        </div>
                      ))}
                    </div>
                    
                    <div className="mt-6">
                      <Button className="w-full">Write a Review</Button>
                    </div>
                  </CardContent>
                </Card>
                
                {/* Pricing teaser */}
                <Card>
                  <CardContent className="p-6">
                    <h3 className="text-lg font-medium mb-4">Pricing Plans</h3>
                    <div className="space-y-3">
                      {displayProduct?.pricing && displayProduct.pricing.length > 0 ? (
                        displayProduct.pricing.map((plan, index) => (
                          <div key={index} className="flex justify-between text-sm border-b border-neutral-100 pb-2 last:border-0">
                            <span className="font-medium">{plan.plan}</span>
                            <span>{plan.price}</span>
                          </div>
                        ))
                      ) : (
                        <div className="text-neutral-500 text-sm">No pricing information available</div>
                      )}
                    </div>
                    <Button variant="link" className="mt-4 w-full" onClick={() => setActiveTab("pricing")}>
                      View Full Pricing Details
                    </Button>
                  </CardContent>
                </Card>
                
                {/* Alternatives teaser */}
                <Card>
                  <CardContent className="p-6">
                    <h3 className="text-lg font-medium mb-4">Alternatives</h3>
                    <div className="space-y-4">
                      {displayProduct?.alternatives && displayProduct.alternatives.length > 0 ? (
                        displayProduct.alternatives.map((alt) => (
                          <div key={alt.id} className="flex items-center">
                            <img 
                              src={alt.logo}
                              alt={`${alt.name} logo`}
                              className="w-10 h-10 rounded object-contain mr-3"
                            />
                            <div className="flex-1">
                              <h4 className="font-medium">{alt.name}</h4>
                              <div className="flex items-center">
                                <StarRating rating={alt.avgRating} size={14} />
                                <span className="text-xs text-neutral-500 ml-1">({alt.reviewCount})</span>
                              </div>
                            </div>
                            <Button variant="outline" size="sm">Compare</Button>
                          </div>
                        ))
                      ) : (
                        <div className="text-neutral-500 text-sm">No alternatives available</div>
                      )}
                    </div>
                    <Button variant="link" className="mt-4 w-full" onClick={() => setActiveTab("alternatives")}>
                      View All Alternatives
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </div>
          )}
          
          {activeTab === "reviews" && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {/* Review list */}
              <div className="md:col-span-2">
                <Card>
                  <CardContent className="p-6">
                    <div className="flex justify-between items-center mb-6">
                      <h2 className="text-xl font-semibold">User Reviews</h2>
                      <div className="flex gap-2">
                        <select className="text-sm border rounded p-1">
                          <option>Sort by: Most Recent</option>
                          <option>Highest Rating</option>
                          <option>Lowest Rating</option>
                          <option>Most Helpful</option>
                        </select>
                        <Button variant="outline" size="sm">
                          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z" />
                          </svg>
                          <span className="ml-1">Filter</span>
                        </Button>
                      </div>
                    </div>
                    
                    <div className="space-y-8">
                      {displayReviews.map((review) => (
                        <div key={review.id} className="border-b border-neutral-200 pb-8 last:border-0">
                          <div className="flex justify-between mb-3">
                            <div className="flex items-center">
                              <Avatar className="h-10 w-10 mr-3">
                                <AvatarImage src={review.user.avatar || undefined} />
                                <AvatarFallback>
                                  {review.user.name.split(' ').map(n => n[0]).join('').toUpperCase()}
                                </AvatarFallback>
                              </Avatar>
                              <div>
                                <h4 className="font-medium">{review.user.name}</h4>
                                <p className="text-sm text-neutral-500">{review.user.title}, {review.user.company}</p>
                              </div>
                            </div>
                            <div className="flex flex-col items-end">
                              <StarRating rating={review.rating} size={16} />
                              <span className="text-xs text-neutral-500">{review.date}</span>
                            </div>
                          </div>
                          
                          <h3 className="text-lg font-semibold mb-2">"{review.title}"</h3>
                          <p className="text-neutral-700 mb-4 whitespace-pre-line">{review.content}</p>
                          
                          <div className="space-y-4">
                            {review.pros && review.pros.length > 0 && (
                              <div>
                                <h5 className="text-sm font-semibold mb-2">What do you like best about {displayProduct.name}?</h5>
                                <div className="flex flex-wrap gap-2">
                                  {review.pros.map((pro, i) => (
                                    <Badge key={i} variant="pros" className="text-xs">{pro}</Badge>
                                  ))}
                                </div>
                              </div>
                            )}
                            
                            {review.cons && review.cons.length > 0 && (
                              <div>
                                <h5 className="text-sm font-semibold mb-2">What do you dislike about {displayProduct.name}?</h5>
                                <div className="flex flex-wrap gap-2">
                                  {review.cons.map((con, i) => (
                                    <Badge key={i} variant="cons" className="text-xs">{con}</Badge>
                                  ))}
                                </div>
                              </div>
                            )}
                          </div>
                          
                          <div className="flex justify-between items-center mt-4">
                            <div className="flex items-center gap-4">
                              <button className="text-sm text-neutral-500 flex items-center gap-1">
                                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 10h4.764a2 2 0 011.789 2.894l-3.5 7A2 2 0 0115.263 21h-4.017c-.163 0-.326-.02-.485-.06L7 20m7-10V5a2 2 0 00-2-2h-.095c-.5 0-.905.405-.905.905 0 .714-.211 1.412-.608 2.006L7 11v9m7-10h-2M7 20H5a2 2 0 01-2-2v-6a2 2 0 012-2h2.5" />
                                </svg>
                                Helpful (12)
                              </button>
                              <button className="text-sm text-neutral-500">Report</button>
                            </div>
                            {review.verified && (
                              <Badge variant="outline" className="text-xs text-green-600 border-green-200 bg-green-50">
                                <svg className="w-3 h-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                                </svg>
                                Verified User
                              </Badge>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                    
                    <div className="flex justify-center mt-8">
                      <Button variant="outline" className="mx-2">Previous</Button>
                      <Button variant="outline" className="bg-primary-50 border-primary-200 text-primary-700 mx-1">1</Button>
                      <Button variant="outline" className="mx-1">2</Button>
                      <Button variant="outline" className="mx-1">3</Button>
                      <Button variant="outline" className="mx-2">Next</Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
              
              {/* Review sidebar */}
              <div>
                <div className="space-y-6">
                  <Card>
                    <CardContent className="p-6">
                      <h3 className="text-lg font-medium mb-4">Rating Breakdown</h3>
                      <div className="flex items-center mb-6">
                        <div className="text-5xl font-bold mr-4">{displayProduct.avgRating.toFixed(1)}</div>
                        <div>
                          <StarRating rating={displayProduct.avgRating} size={20} />
                          <span className="text-sm text-neutral-500 block mt-1">{displayProduct.reviewCount} reviews</span>
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        {[5, 4, 3, 2, 1].map((rating) => (
                          <div key={rating} className="flex items-center text-sm">
                            <div className="w-10">{rating} ★</div>
                            <div className="flex-1 mx-2 bg-neutral-200 rounded-full h-2">
                              <div 
                                className="bg-amber-500 h-2 rounded-full" 
                                style={{ width: `${Math.max(0, Math.min(100, (6 - rating) * 20 - (Math.random() * 15)))}%` }} 
                              ></div>
                            </div>
                            <div className="w-10 text-right">{Math.floor(Math.random() * 40 + 10)}%</div>
                          </div>
                        ))}
                      </div>
                      
                      <Separator className="my-6" />
                      
                      <h3 className="text-lg font-medium mb-4">Review this Product</h3>
                      <p className="text-sm text-neutral-600 mb-4">Share your experience to help others make better decisions.</p>
                      
                      <Button className="w-full">Write a Review</Button>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardContent className="p-6">
                      <h3 className="text-lg font-medium mb-4">Review Guidelines</h3>
                      <div className="space-y-3 text-sm text-neutral-700">
                        <p>• Be specific and detailed about your experience</p>
                        <p>• Mention pros and cons of the product</p>
                        <p>• Focus on features and functionality</p>
                        <p>• Be honest and constructive</p>
                        <p>• Keep it professional and respectful</p>
                      </div>
                      <Button variant="link" className="text-sm p-0 mt-3">
                        Read full guidelines
                      </Button>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </div>
          )}
          
          {activeTab === "pricing" && (
            <Card>
              <CardContent className="p-6">
                <h2 className="text-xl font-semibold mb-6">Pricing Plans</h2>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                  {displayProduct?.pricing && displayProduct.pricing.length > 0 ? (
                    displayProduct.pricing.map((plan, index) => (
                      <div key={index} className="border border-neutral-200 rounded-lg p-6 bg-white">
                        <h3 className="text-lg font-bold mb-2">{plan.plan}</h3>
                        <div className="text-2xl font-bold text-primary-700 mb-4">{plan.price}</div>
                        <ul className="space-y-2 mb-6">
                          {plan.features && plan.features.length > 0 && plan.features.map((feature, i) => (
                            <li key={i} className="flex items-start">
                              <svg className="w-5 h-5 text-green-600 mr-2 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                              </svg>
                              <span className="text-neutral-700">{typeof feature === 'object' && feature.feature ? feature.feature : feature}</span>
                            </li>
                          ))}
                        </ul>
                        <Button variant={index === 1 ? "default" : "outline"} className="w-full">
                          {index === 0 ? "Get Started Free" : "Learn More"}
                        </Button>
                      </div>
                    ))
                  ) : (
                    <div className="col-span-3 text-center py-8 text-neutral-500">
                      No pricing plans available
                    </div>
                  )}
                </div>
                
                <div className="bg-neutral-50 border border-neutral-200 rounded-lg p-6">
                  <h3 className="text-lg font-semibold mb-4">Additional Pricing Information</h3>
                  <div className="space-y-4 text-neutral-700">
                    <p>• All prices shown are billed annually. Monthly billing available at higher rates.</p>
                    <p>• Enterprise plans with custom pricing and features are available for large organizations.</p>
                    <p>• Educational and non-profit discounts are available.</p>
                    <p>• All paid plans include a free 30-day trial.</p>
                  </div>
                  <div className="mt-4">
                    <Button variant="outline" size="sm" className="mr-4">Contact Sales</Button>
                    <Button variant="link" size="sm">
                      Visit pricing page
                      <ArrowRightIcon className="ml-1 h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
          
          {activeTab === "alternatives" && (
            <Card>
              <CardContent className="p-6">
                <h2 className="text-xl font-semibold mb-6">Alternatives to {displayProduct.name}</h2>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {displayProduct?.alternatives && displayProduct.alternatives.length > 0 ? (
                    // Duplicating alternatives to show more examples
                    [...(displayProduct.alternatives || []), ...(displayProduct.alternatives || [])].map((alt, index) => (
                      <div key={`${alt.id}-${index}`} className="border border-neutral-200 rounded-lg p-5 bg-white flex">
                        <img 
                          src={alt.logo}
                          alt={`${alt.name} logo`}
                          className="w-16 h-16 rounded object-contain mr-4"
                        />
                        <div className="flex-1">
                          <h3 className="text-lg font-semibold mb-1">{alt.name}</h3>
                          <div className="flex items-center mb-2">
                            <StarRating rating={alt.avgRating} size={16} />
                            <span className="text-sm text-neutral-500 ml-2">({alt.reviewCount} reviews)</span>
                          </div>
                          <p className="text-sm text-neutral-600 mb-3 line-clamp-2">
                            {index % 2 === 0 
                              ? `${alt.name} is an alternative to ${displayProduct?.name || 'this product'} that offers similar team communication capabilities with additional features for enterprise organizations.`
                              : `${alt.name} provides channel-based messaging similar to ${displayProduct?.name || 'this product'} but with a different focus on community building and voice chat.`
                            }
                          </p>
                          <div className="flex justify-between">
                            <Button variant="link" className="text-sm p-0 h-6">View Details</Button>
                            <Button variant="outline" size="sm">Compare</Button>
                          </div>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="col-span-2 text-center py-8 text-neutral-500">
                      No alternatives available for this product
                    </div>
                  )}
                </div>
                
                <div className="flex justify-center mt-8">
                  <Button variant="outline">Load More Alternatives</Button>
                </div>
              </CardContent>
            </Card>
          )}
          
          {activeTab === "questions" && (
            <Card>
              <CardContent className="p-6">
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-xl font-semibold">Questions & Answers</h2>
                  <Button>Ask a Question</Button>
                </div>
                
                <div className="space-y-6">
                  {[1, 2, 3].map((id) => (
                    <div key={id} className="border-b border-neutral-200 pb-6 last:border-0">
                      <h3 className="text-lg font-semibold mb-2">
                        How does {displayProduct?.name || 'this product'} compare to {id === 1 ? 'Microsoft Teams' : id === 2 ? 'Discord' : 'Zoom'} for team communication?
                      </h3>
                      
                      <div className="bg-neutral-50 border border-neutral-200 rounded-lg p-4 mb-4">
                        <div className="flex justify-between mb-3">
                          <div className="flex items-center">
                            <Avatar className="h-8 w-8 mr-2">
                              <AvatarFallback>EX</AvatarFallback>
                            </Avatar>
                            <div>
                              <h4 className="text-sm font-medium">Expert Answer</h4>
                              <p className="text-xs text-neutral-500">Product Specialist • {displayProduct?.name || 'this product'}</p>
                            </div>
                          </div>
                          <span className="text-xs text-neutral-500">2 weeks ago</span>
                        </div>
                        
                        <p className="text-neutral-700 text-sm mb-3">
                          {id === 1 
                            ? `While both Slack and Microsoft Teams offer team messaging and collaboration features, Slack is often preferred for its intuitive interface and extensive third-party integrations. Teams is more deeply integrated with Microsoft 365 and offers robust video conferencing. Slack's channel organization and searchability are often cited as superior, while Teams provides better document collaboration within the Microsoft ecosystem.`
                            : id === 2
                              ? `Slack and Discord serve different primary audiences. Slack is built for business communication with features like shared channels between organizations and compliance features. Discord originated for gaming communities but has expanded to other use cases. Slack offers more business integrations, while Discord excels at voice chat and community building. For professional team communication, Slack typically provides a more appropriate solution with better organization and search capabilities.`
                              : `Slack and Zoom serve complementary rather than competing functions. Slack is primarily a messaging and collaboration platform with limited video capabilities, while Zoom focuses on high-quality video conferencing. Many organizations use both: Slack for ongoing team communication and Zoom for scheduled meetings and webinars. Slack does integrate with Zoom, allowing you to start Zoom calls directly from Slack channels.`
                          }
                        </p>
                        
                        <div className="flex items-center text-sm">
                          <button className="text-neutral-500 flex items-center mr-4">
                            <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 10h4.764a2 2 0 011.789 2.894l-3.5 7A2 2 0 0115.263 21h-4.017c-.163 0-.326-.02-.485-.06L7 20m7-10V5a2 2 0 00-2-2h-.095c-.5 0-.905.405-.905.905 0 .714-.211 1.412-.608 2.006L7 11v9m7-10h-2M7 20H5a2 2 0 01-2-2v-6a2 2 0 012-2h2.5" />
                            </svg>
                            Helpful (18)
                          </button>
                          <button className="text-neutral-500">Report</button>
                        </div>
                      </div>
                      
                      <div className="pl-4 border-l-2 border-neutral-200">
                        <h4 className="text-sm font-medium mb-3">Community Answers (3)</h4>
                        
                        <div className="space-y-4">
                          <div>
                            <div className="flex justify-between mb-2">
                              <div className="flex items-center">
                                <Avatar className="h-6 w-6 mr-2">
                                  <AvatarFallback>JD</AvatarFallback>
                                </Avatar>
                                <span className="text-sm font-medium">John D.</span>
                              </div>
                              <span className="text-xs text-neutral-500">3 weeks ago</span>
                            </div>
                            <p className="text-neutral-700 text-sm mb-2">
                              In my experience, Slack has better organization with channels and threads, which helps keep conversations focused.
                            </p>
                            <div className="flex items-center text-xs">
                              <button className="text-neutral-500 flex items-center mr-3">
                                <svg className="w-3 h-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 10h4.764a2 2 0 011.789 2.894l-3.5 7A2 2 0 0115.263 21h-4.017c-.163 0-.326-.02-.485-.06L7 20m7-10V5a2 2 0 00-2-2h-.095c-.5 0-.905.405-.905.905 0 .714-.211 1.412-.608 2.006L7 11v9m7-10h-2M7 20H5a2 2 0 01-2-2v-6a2 2 0 012-2h2.5" />
                                </svg>
                                Helpful (5)
                              </button>
                              <button className="text-neutral-500">Report</button>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      <div className="mt-4 text-right">
                        <Button variant="outline" size="sm">View All Answers</Button>
                      </div>
                    </div>
                  ))}
                </div>
                
                <div className="flex justify-center mt-8">
                  <Button variant="outline">Load More Questions</Button>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </main>
      
      <Footer />
    </div>
  );
}