import React, { useState } from 'react';
import { useLocation } from 'wouter';
import { Navbar } from '@/components/layout/navbar';
import { Footer } from '@/components/layout/footer';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ProductCard } from '@/components/products/product-card';
import { useQuery } from '@tanstack/react-query';
import { SearchIcon } from '@/components/ui/icons';
import { Product } from '@shared/schema';
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';

export default function ProductsPage() {
  const [location] = useLocation();
  const [searchTerm, setSearchTerm] = useState('');
  const [sortBy, setSortBy] = useState('rating');

  const isMyReviews = location === '/my-reviews';
  const pageTitle = isMyReviews ? 'My Reviews' : 'All Products';

  const { data: products, isLoading, error } = useQuery<Product[]>({
    queryKey: [isMyReviews ? '/api/reviews' : '/api/products', { userId: isMyReviews ? 'current' : undefined }],
  });

  // Filter products based on search term
  const filteredProducts = products?.filter(product => {
    if (!product) return false;
    return (
      product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.description.toLowerCase().includes(searchTerm.toLowerCase())
    );
  });

  // Sort products
  const sortedProducts = React.useMemo(() => {
    if (!filteredProducts) return [];
    
    return [...filteredProducts].sort((a, b) => {
      if (!a || !b) return 0;
      
      switch (sortBy) {
        case 'rating':
          return (b.avgRating || 0) - (a.avgRating || 0);
        case 'reviews':
          return (b.reviewCount || 0) - (a.reviewCount || 0);
        case 'name-asc':
          return a.name.localeCompare(b.name);
        case 'name-desc':
          return b.name.localeCompare(a.name);
        default:
          return 0;
      }
    });
  }, [filteredProducts, sortBy]);

  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-grow py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-neutral-900 mb-4">{pageTitle}</h1>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-between items-start">
              <div className="relative flex-1 w-full sm:max-w-md">
                <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                  <SearchIcon className="h-4 w-4 text-neutral-400" />
                </div>
                <Input 
                  type="search" 
                  placeholder="Search products..." 
                  className="pl-10"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              
              <div className="flex gap-2 w-full sm:w-auto">
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="w-full sm:w-[180px]">
                    <SelectValue placeholder="Sort by" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectGroup>
                      <SelectItem value="rating">Highest Rating</SelectItem>
                      <SelectItem value="reviews">Most Reviews</SelectItem>
                      <SelectItem value="name-asc">Name (A-Z)</SelectItem>
                      <SelectItem value="name-desc">Name (Z-A)</SelectItem>
                    </SelectGroup>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
          
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className="border border-neutral-200 rounded-lg p-6 space-y-4">
                  <div className="flex items-center gap-4">
                    <Skeleton className="h-12 w-12 rounded-md" />
                    <div>
                      <Skeleton className="h-4 w-24" />
                      <Skeleton className="h-3 w-16 mt-2" />
                    </div>
                  </div>
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-3/4" />
                </div>
              ))}
            </div>
          ) : error ? (
            <div className="text-center p-8">
              <p className="text-red-500">Failed to load products. Please try again later.</p>
              <Button variant="outline" className="mt-4">Refresh</Button>
            </div>
          ) : sortedProducts?.length === 0 ? (
            <div className="text-center p-8">
              <h3 className="text-xl font-medium text-neutral-900 mb-2">No products found</h3>
              <p className="text-neutral-600 mb-4">Try adjusting your search or filters.</p>
              {searchTerm && (
                <Button 
                  variant="outline" 
                  onClick={() => setSearchTerm('')}
                >
                  Clear Search
                </Button>
              )}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {sortedProducts?.map(product => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}
          
          {products && products.length > 0 && (
            <div className="mt-12 text-center">
              <p className="text-neutral-600 mb-4">
                Showing {sortedProducts?.length} of {products.length} products
              </p>
            </div>
          )}
        </div>
      </main>
      <Footer />
    </div>
  );
}
