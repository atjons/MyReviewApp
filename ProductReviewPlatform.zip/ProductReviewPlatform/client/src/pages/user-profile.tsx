import React, { useState } from 'react';
import { Navbar } from '@/components/layout/navbar';
import { Footer } from '@/components/layout/footer';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { StarRating } from '@/components/ui/star-rating';
import { useAuth } from '@/hooks/use-auth';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'wouter';

export default function UserProfile() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<string>("profile");
  
  // Fetch user's reviews
  const { data: userReviews } = useQuery({
    queryKey: ['/api/reviews', { userId: user?.id }],
    enabled: !!user?.id,
  });
  
  // Fetch user's products (ones they've reviewed)
  const { data: userProducts } = useQuery({
    queryKey: ['/api/user/products'],
    enabled: !!user?.id,
  });
  
  // Mock data for achievements (badges)
  const userStats = {
    reviewCount: userReviews?.length || 0,
    badgeCount: 3,
    questionsAnswered: 5,
    votesReceived: 12
  };
  
  if (!user) {
    return (
      <div className="flex flex-col min-h-screen">
        <Navbar />
        <main className="flex-grow flex items-center justify-center">
          <div className="text-center">
            <h1 className="text-2xl font-bold mb-4">Please log in to view your profile</h1>
            <Link href="/auth">
              <Button>Go to Login</Button>
            </Link>
          </div>
        </main>
        <Footer />
      </div>
    );
  }
  
  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      
      {/* Welcome banner */}
      <div className="bg-gradient-to-r from-primary-900 to-primary-800 text-white py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row justify-between items-center">
            <div>
              <h1 className="text-2xl font-bold">Welcome to G2, {user.fullName || user.username}!</h1>
              <p className="text-primary-100">Tell us about where you work.</p>
            </div>
            
            <div className="mt-4 sm:mt-0 flex items-center gap-4">
              <div>
                <input 
                  type="text" 
                  placeholder="Company Website" 
                  className="px-3 py-2 rounded border border-gray-300 text-gray-900 text-sm w-full"
                />
              </div>
              <div>
                <input 
                  type="text" 
                  placeholder="Company Name" 
                  className="px-3 py-2 rounded border border-gray-300 text-gray-900 text-sm w-full"
                />
              </div>
              <Button>Submit</Button>
              <button className="text-white">&times;</button>
            </div>
          </div>
        </div>
      </div>
      
      <main className="flex-grow py-8 bg-neutral-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {/* Sidebar */}
            <div className="md:col-span-1">
              <Card className="bg-white shadow-sm">
                <CardContent className="p-6 flex flex-col items-center text-center">
                  <Avatar className="h-24 w-24 mb-4">
                    <AvatarImage src={user.avatar || undefined} alt={user.fullName || user.username} />
                    <AvatarFallback className="text-lg">
                      {(user.fullName || user.username)
                        .split(' ')
                        .map(n => n[0])
                        .join('')
                        .toUpperCase()
                        .substring(0, 2)}
                    </AvatarFallback>
                  </Avatar>
                  
                  <h2 className="text-xl font-semibold">{user.fullName || user.username}</h2>
                  <p className="text-sm text-neutral-500">{user.title || "Not specified"}</p>
                  <p className="text-xs text-neutral-400 mt-1">Member since {user.createdAt ? new Date(user.createdAt).toLocaleDateString() : "N/A"}</p>
                  
                  <div className="w-full mt-6">
                    <Tabs defaultValue="profile" value={activeTab} onValueChange={setActiveTab} className="w-full">
                      <TabsList className="grid grid-cols-1 w-full">
                        <TabsTrigger value="profile" className="text-left pl-4 justify-start">
                          <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5.121 17.804A13.937 13.937 0 0112 16c2.5 0 4.847.655 6.879 1.804M15 10a3 3 0 11-6 0 3 3 0 016 0zm6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                          </svg>
                          Profile Details
                        </TabsTrigger>
                        <TabsTrigger value="reviews" className="text-left pl-4 justify-start">
                          <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                          </svg>
                          Reviews
                        </TabsTrigger>
                        <TabsTrigger value="products" className="text-left pl-4 justify-start">
                          <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
                          </svg>
                          Products
                        </TabsTrigger>
                        <TabsTrigger value="achievements" className="text-left pl-4 justify-start">
                          <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
                          </svg>
                          Achievements
                        </TabsTrigger>
                      </TabsList>
                      
                      {/* TabsContent components go here inside the Tabs component */}
                      <TabsContent value="profile" className="hidden">Profile Tab Content</TabsContent>
                      <TabsContent value="reviews" className="hidden">Reviews Tab Content</TabsContent>
                      <TabsContent value="products" className="hidden">Products Tab Content</TabsContent>
                      <TabsContent value="achievements" className="hidden">Achievements Tab Content</TabsContent>
                    </Tabs>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            {/* Main Content */}
            <div className="md:col-span-3">
              <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
                <div className="flex items-center gap-4 mb-4">
                  <svg className="w-6 h-6 text-primary-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  <h2 className="text-lg font-semibold">Welcome! Check out {user.fullName || user.username}'s stats:</h2>
                </div>
                
                <div className="grid grid-cols-4 gap-4 mb-6">
                  <div className="text-center p-4 border border-neutral-200 rounded-lg">
                    <div className="bg-primary-100 rounded-full w-12 h-12 mx-auto mb-2 flex items-center justify-center">
                      <svg className="w-6 h-6 text-primary-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                      </svg>
                    </div>
                    <p className="text-sm font-medium">They've written</p>
                    <p className="text-lg font-bold text-primary-600">{userStats.reviewCount} {userStats.reviewCount === 1 ? 'review' : 'reviews'}</p>
                    <p className="text-xs text-neutral-500">so far</p>
                  </div>
                  
                  <div className="text-center p-4 border border-neutral-200 rounded-lg">
                    <div className="bg-blue-100 rounded-full w-12 h-12 mx-auto mb-2 flex items-center justify-center">
                      <svg className="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
                      </svg>
                    </div>
                    <p className="text-sm font-medium">They've earned</p>
                    <p className="text-lg font-bold text-blue-600">{userStats.badgeCount} {userStats.badgeCount === 1 ? 'badge' : 'badges'}</p>
                    <p className="text-xs text-neutral-500"></p>
                  </div>
                  
                  <div className="text-center p-4 border border-neutral-200 rounded-lg">
                    <div className="bg-green-100 rounded-full w-12 h-12 mx-auto mb-2 flex items-center justify-center">
                      <svg className="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                    </div>
                    <p className="text-sm font-medium">They've answered</p>
                    <p className="text-lg font-bold text-green-600">{userStats.questionsAnswered} common</p>
                    <p className="text-xs text-neutral-500">questions</p>
                  </div>
                  
                  <div className="text-center p-4 border border-neutral-200 rounded-lg">
                    <div className="bg-amber-100 rounded-full w-12 h-12 mx-auto mb-2 flex items-center justify-center">
                      <svg className="w-6 h-6 text-amber-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 10h4.764a2 2 0 011.789 2.894l-3.5 7A2 2 0 0115.263 21h-4.017c-.163 0-.326-.02-.485-.06L7 20m7-10V5a2 2 0 00-2-2h-.095c-.5 0-.905.405-.905.905 0 .714-.211 1.412-.608 2.006L7 11v9m7-10h-2M7 20H5a2 2 0 01-2-2v-6a2 2 0 012-2h2.5" />
                      </svg>
                    </div>
                    <p className="text-sm font-medium">Their answers</p>
                    <p className="text-lg font-bold text-amber-600">have received</p>
                    <p className="text-xs text-neutral-500">{userStats.votesReceived} votes</p>
                  </div>
                </div>
              </div>
              
              {/* Conditional content based on the active tab */}
              {activeTab === "profile" && (
                <Card className="bg-white shadow-sm">
                  <CardContent className="p-6">
                    <h2 className="text-xl font-semibold mb-4">Profile Details</h2>
                    <div className="space-y-4">
                      <div>
                        <h3 className="text-sm font-medium text-neutral-500">Full Name</h3>
                        <p>{user.fullName || "Not specified"}</p>
                      </div>
                      <div>
                        <h3 className="text-sm font-medium text-neutral-500">Username</h3>
                        <p>{user.username}</p>
                      </div>
                      <div>
                        <h3 className="text-sm font-medium text-neutral-500">Email</h3>
                        <p>{user.email}</p>
                      </div>
                      <div>
                        <h3 className="text-sm font-medium text-neutral-500">Job Title</h3>
                        <p>{user.title || "Not specified"}</p>
                      </div>
                      <div>
                        <h3 className="text-sm font-medium text-neutral-500">Company</h3>
                        <p>{user.company || "Not specified"}</p>
                      </div>
                      <div>
                        <h3 className="text-sm font-medium text-neutral-500">Member Since</h3>
                        <p>{user.createdAt ? new Date(user.createdAt).toLocaleDateString() : "N/A"}</p>
                      </div>
                    </div>
                    <div className="mt-6">
                      <Button variant="outline">Edit Profile</Button>
                    </div>
                  </CardContent>
                </Card>
              )}
              
              {activeTab === "products" && (
                <>
                  <div className="bg-white rounded-lg shadow-sm mb-8">
                    <div className="p-6">
                      <div className="flex items-center justify-between mb-4">
                        <h2 className="text-xl font-semibold">Products You Both Use</h2>
                        <Button variant="link" className="text-sm">View All</Button>
                      </div>
                      
                      {userProducts && userProducts.length > 0 ? (
                        <div className="space-y-4">
                          {userProducts.map((product: any) => (
                            <div key={product.id} className="flex items-center justify-between border-b pb-4">
                              <div className="flex items-center">
                                <img 
                                  src={product.logo || `https://ui-avatars.com/api/?name=${product.name}&background=random`}
                                  alt={product.name}
                                  className="w-12 h-12 rounded-lg object-cover mr-4"
                                />
                                <div>
                                  <h3 className="font-medium">{product.name}</h3>
                                  <div className="flex items-center mt-1">
                                    <StarRating rating={product.avgRating} size={14} />
                                    <span className="text-xs text-neutral-500 ml-1">({product.reviewCount} reviews)</span>
                                  </div>
                                </div>
                              </div>
                              <Button variant="outline" size="sm">View Product</Button>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className="text-center py-12">
                          <div className="mx-auto w-24 h-24 text-neutral-300 mb-4">
                            <svg fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                              <path d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
                            </svg>
                          </div>
                          <p className="text-neutral-600">You don't have any products in common with {user.fullName || user.username}.</p>
                          <Button className="mt-4">Add more products to your stack</Button>
                        </div>
                      )}
                    </div>
                  </div>
                  
                  <div className="bg-white rounded-lg shadow-sm">
                    <div className="p-6">
                      <div className="flex items-center justify-between mb-4">
                        <h2 className="text-xl font-semibold">{user.fullName || user.username}'s Products</h2>
                        <Button variant="link" className="text-sm">View All</Button>
                      </div>
                      
                      {userProducts && userProducts.length > 0 ? (
                        <div className="space-y-4">
                          {userProducts.map((product: any) => (
                            <div key={product.id} className="flex items-center justify-between border-b pb-4">
                              <div className="flex items-center">
                                <img 
                                  src={product.logo || `https://ui-avatars.com/api/?name=${product.name}&background=random`}
                                  alt={product.name}
                                  className="w-12 h-12 rounded-lg object-cover mr-4"
                                />
                                <div>
                                  <h3 className="font-medium">{product.name}</h3>
                                </div>
                              </div>
                              <Button variant="outline" size="sm">View Product</Button>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className="text-center py-8">
                          <p className="text-neutral-600">{user.fullName || user.username} hasn't added any products yet.</p>
                        </div>
                      )}
                    </div>
                  </div>
                </>
              )}
              
              {activeTab === "reviews" && (
                <div className="bg-white rounded-lg shadow-sm">
                  <div className="p-6">
                    <h2 className="text-xl font-semibold mb-4">Recent Reviews</h2>
                    
                    {userReviews && userReviews.length > 0 ? (
                      <div className="space-y-8">
                        {userReviews.map((review: any) => (
                          <div key={review.id} className="border-b pb-6">
                            <div className="flex items-center justify-between mb-4">
                              <div className="flex items-center">
                                <img 
                                  src={review.product?.logo || `https://ui-avatars.com/api/?name=${review.product?.name}&background=random`}
                                  alt={review.product?.name}
                                  className="w-12 h-12 rounded-lg object-cover mr-4"
                                />
                                <div>
                                  <h3 className="font-medium">{review.product?.name}</h3>
                                  <StarRating rating={review.rating} size={16} />
                                </div>
                              </div>
                              <div className="text-sm text-neutral-500">
                                {new Date(review.createdAt).toLocaleDateString()}
                              </div>
                            </div>
                            
                            <h4 className="text-lg font-semibold mb-2">"{review.title}"</h4>
                            <p className="text-neutral-700 mb-4">{review.content}</p>
                            
                            <div className="space-y-2">
                              {review.pros && review.pros.length > 0 && (
                                <div>
                                  <h5 className="text-sm font-semibold text-neutral-900 mb-1">What do you like best about {review.product?.name}?</h5>
                                  <div className="flex flex-wrap gap-2">
                                    {review.pros.map((pro: string, i: number) => (
                                      <Badge key={i} variant="pros" className="text-xs">{pro}</Badge>
                                    ))}
                                  </div>
                                </div>
                              )}
                              
                              {review.cons && review.cons.length > 0 && (
                                <div className="mt-4">
                                  <h5 className="text-sm font-semibold text-neutral-900 mb-1">What do you dislike about {review.product?.name}?</h5>
                                  <div className="flex flex-wrap gap-2">
                                    {review.cons.map((con: string, i: number) => (
                                      <Badge key={i} variant="cons" className="text-xs">{con}</Badge>
                                    ))}
                                  </div>
                                </div>
                              )}
                            </div>
                            
                            <div className="mt-4 flex justify-end">
                              <Button variant="link" size="sm">Read Full Review</Button>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-12">
                        <p className="text-neutral-600">No reviews yet. Share your experience by writing a review!</p>
                        <Link href="/products">
                          <Button className="mt-4">Browse Products to Review</Button>
                        </Link>
                      </div>
                    )}
                  </div>
                </div>
              )}
              
              {activeTab === "achievements" && (
                <div className="bg-white rounded-lg shadow-sm">
                  <div className="p-6">
                    <h2 className="text-xl font-semibold mb-8">Achievements & Badges</h2>
                    
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                      <div className="bg-gradient-to-br from-amber-50 to-amber-100 rounded-lg p-6 text-center border border-amber-200">
                        <div className="bg-amber-500 text-white rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                          <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                          </svg>
                        </div>
                        <h3 className="text-lg font-bold text-amber-800">First Review</h3>
                        <p className="text-amber-700 text-sm mt-2">Awarded for publishing your first product review</p>
                      </div>
                      
                      <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg p-6 text-center border border-blue-200">
                        <div className="bg-blue-500 text-white rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                          <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                          </svg>
                        </div>
                        <h3 className="text-lg font-bold text-blue-800">Community Helper</h3>
                        <p className="text-blue-700 text-sm mt-2">Awarded for answering 5+ community questions</p>
                      </div>
                      
                      <div className="bg-gradient-to-br from-purple-50 to-purple-100 rounded-lg p-6 text-center border border-purple-200">
                        <div className="bg-purple-500 text-white rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                          <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z" />
                          </svg>
                        </div>
                        <h3 className="text-lg font-bold text-purple-800">Verified Reviewer</h3>
                        <p className="text-purple-700 text-sm mt-2">Awarded for completing profile verification</p>
                      </div>
                    </div>
                    
                    <div className="mt-8 text-center">
                      <p className="text-neutral-500 mb-4">Keep contributing to earn more badges!</p>
                      <Link href="/review">
                        <Button>Write a Review</Button>
                      </Link>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}