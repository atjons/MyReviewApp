import React, { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { Navbar } from '@/components/layout/navbar';
import { Footer } from '@/components/layout/footer';
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { insertReviewSchema } from "@shared/schema";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useQuery, useMutation } from '@tanstack/react-query';
import { useAuth } from '@/hooks/use-auth';
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Loader2, X } from "lucide-react";
import { Badge } from '@/components/ui/badge';

// Review schema with validation
const reviewFormSchema = z.object({
  title: z.string().min(5, { message: "Title must be at least 5 characters" }).max(100),
  content: z.string().min(20, { message: "Review must be at least 20 characters" }),
  rating: z.string().transform(val => parseInt(val)).refine(val => val >= 1 && val <= 5, { message: "Rating must be between 1 and 5" }),
  pros: z.array(z.string()).optional(),
  cons: z.array(z.string()).optional(),
  productId: z.number().positive({ message: "Please select a product" }),
});

type ReviewFormValues = z.infer<typeof reviewFormSchema>;

export default function WriteReview() {
  const [, navigate] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  const [prosInput, setProsInput] = useState("");
  const [consInput, setConsInput] = useState("");
  
  // Get product ID from URL if provided
  const searchParams = new URLSearchParams(window.location.search);
  const productIdParam = searchParams.get('productId');
  
  // Fetch all products
  const { data: products, isLoading: isLoadingProducts } = useQuery({
    queryKey: ['/api/products'],
  });
  
  // Fetch product details if productId is provided
  const { data: product, isLoading: isLoadingProduct } = useQuery({
    queryKey: [`/api/products/${productIdParam}`],
    enabled: !!productIdParam,
  });
  
  const form = useForm<ReviewFormValues>({
    resolver: zodResolver(reviewFormSchema),
    defaultValues: {
      title: "",
      content: "",
      rating: "5",
      pros: [],
      cons: [],
      productId: productIdParam ? parseInt(productIdParam) : 0,
    },
  });
  
  // Submit review
  const submitReviewMutation = useMutation({
    mutationFn: async (values: ReviewFormValues) => {
      const res = await apiRequest("POST", "/api/reviews", {
        ...values,
        userId: user?.id,
      });
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Review submitted successfully",
        description: "Thank you for sharing your experience!",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/reviews'] });
      queryClient.invalidateQueries({ queryKey: ['/api/products'] });
      navigate('/my-reviews');
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to submit review",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Update product ID if changed in URL
  useEffect(() => {
    if (productIdParam && product) {
      form.setValue('productId', product.id);
    }
  }, [product, productIdParam, form]);
  
  // Handle form submission
  const onSubmit = (values: ReviewFormValues) => {
    submitReviewMutation.mutate(values);
  };
  
  // Handle pros and cons
  const handleAddPro = () => {
    if (prosInput.trim() && form.getValues().pros) {
      form.setValue('pros', [...form.getValues().pros!, prosInput.trim()]);
      setProsInput("");
    }
  };
  
  const handleAddCon = () => {
    if (consInput.trim() && form.getValues().cons) {
      form.setValue('cons', [...form.getValues().cons!, consInput.trim()]);
      setConsInput("");
    }
  };
  
  const handleRemovePro = (index: number) => {
    const updatedPros = form.getValues().pros?.filter((_, i) => i !== index);
    form.setValue('pros', updatedPros || []);
  };
  
  const handleRemoveCon = (index: number) => {
    const updatedCons = form.getValues().cons?.filter((_, i) => i !== index);
    form.setValue('cons', updatedCons || []);
  };
  
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>, type: 'pros' | 'cons') => {
    if (e.key === 'Enter') {
      e.preventDefault();
      if (type === 'pros') {
        handleAddPro();
      } else {
        handleAddCon();
      }
    }
  };

  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-grow py-8">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-neutral-900 mb-2">Write a Review</h1>
            <p className="text-neutral-600">
              Share your experience with a software product to help others make informed decisions.
            </p>
          </div>
          
          <div className="bg-white rounded-lg border border-neutral-200 p-6 shadow">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <FormField
                  control={form.control}
                  name="productId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Select Product</FormLabel>
                      <Select
                        disabled={!!productIdParam || isLoadingProducts}
                        onValueChange={(value) => field.onChange(parseInt(value))}
                        value={field.value?.toString() || ""}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select a product to review" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {isLoadingProducts ? (
                            <div className="flex items-center justify-center p-4">
                              <Loader2 className="h-5 w-5 animate-spin text-neutral-500" />
                            </div>
                          ) : products?.length === 0 ? (
                            <div className="p-4 text-center text-neutral-500">
                              No products available
                            </div>
                          ) : (
                            products?.map((product) => (
                              <SelectItem key={product.id} value={product.id.toString()}>
                                {product.name}
                              </SelectItem>
                            ))
                          )}
                        </SelectContent>
                      </Select>
                      <FormDescription>
                        {productIdParam && product ? (
                          <>You are reviewing <strong>{product.name}</strong></>
                        ) : (
                          "Choose the software product you want to review"
                        )}
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="rating"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Overall Rating</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value.toString()}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select a rating" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="5">5 - Excellent</SelectItem>
                          <SelectItem value="4">4 - Very Good</SelectItem>
                          <SelectItem value="3">3 - Good</SelectItem>
                          <SelectItem value="2">2 - Fair</SelectItem>
                          <SelectItem value="1">1 - Poor</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormDescription>
                        How would you rate your overall experience with this product?
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Review Title</FormLabel>
                      <FormControl>
                        <Input placeholder="Summarize your experience in a title" {...field} />
                      </FormControl>
                      <FormDescription>
                        Create a concise title that summarizes your review
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="content"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Review Details</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Share your experience with this product in detail..." 
                          rows={6}
                          {...field} 
                        />
                      </FormControl>
                      <FormDescription>
                        Include details about your experience, use cases, and what you liked or disliked
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="pros"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Pros</FormLabel>
                        <div className="space-y-2">
                          <div className="flex">
                            <Input
                              placeholder="Add a pro"
                              value={prosInput}
                              onChange={(e) => setProsInput(e.target.value)}
                              onKeyDown={(e) => handleKeyDown(e, 'pros')}
                              className="rounded-r-none"
                            />
                            <Button 
                              type="button" 
                              onClick={handleAddPro}
                              className="rounded-l-none"
                            >
                              Add
                            </Button>
                          </div>
                          
                          <div className="flex flex-wrap gap-2 mt-2">
                            {field.value?.map((pro, index) => (
                              <Badge key={index} variant="pros" className="flex items-center gap-1 pl-2">
                                {pro}
                                <Button
                                  type="button"
                                  variant="ghost"
                                  onClick={() => handleRemovePro(index)}
                                  className="h-5 w-5 p-0 ml-1"
                                >
                                  <X className="h-3 w-3" />
                                </Button>
                              </Badge>
                            ))}
                          </div>
                        </div>
                        <FormDescription>
                          What did you like about this product?
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="cons"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Cons</FormLabel>
                        <div className="space-y-2">
                          <div className="flex">
                            <Input
                              placeholder="Add a con"
                              value={consInput}
                              onChange={(e) => setConsInput(e.target.value)}
                              onKeyDown={(e) => handleKeyDown(e, 'cons')}
                              className="rounded-r-none"
                            />
                            <Button 
                              type="button" 
                              onClick={handleAddCon}
                              className="rounded-l-none"
                            >
                              Add
                            </Button>
                          </div>
                          
                          <div className="flex flex-wrap gap-2 mt-2">
                            {field.value?.map((con, index) => (
                              <Badge key={index} variant="cons" className="flex items-center gap-1 pl-2">
                                {con}
                                <Button
                                  type="button"
                                  variant="ghost"
                                  onClick={() => handleRemoveCon(index)}
                                  className="h-5 w-5 p-0 ml-1"
                                >
                                  <X className="h-3 w-3" />
                                </Button>
                              </Badge>
                            ))}
                          </div>
                        </div>
                        <FormDescription>
                          What could be improved about this product?
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <div className="flex justify-end gap-4 pt-4">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => navigate('/products')}
                  >
                    Cancel
                  </Button>
                  <Button 
                    type="submit"
                    disabled={submitReviewMutation.isPending}
                  >
                    {submitReviewMutation.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Submitting...
                      </>
                    ) : "Submit Review"}
                  </Button>
                </div>
              </form>
            </Form>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
