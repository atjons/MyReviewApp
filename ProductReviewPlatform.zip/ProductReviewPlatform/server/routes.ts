import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { z } from "zod";
import { 
  insertReviewSchema, 
  insertProductSchema, 
  insertCategorySchema, 
  insertProductFeatureSchema,
  userRoles, 
  UserRole 
} from "@shared/schema";

// Middleware to check if user is authenticated
const isAuthenticated = (req: Request, res: Response, next: NextFunction) => {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ message: "Unauthorized - Please log in" });
};

// Middleware to check if user has product admin or super admin role
const isProductAdmin = (req: Request, res: Response, next: NextFunction) => {
  if (req.isAuthenticated() && 
      (req.user.role === userRoles.PRODUCT_ADMIN || req.user.role === userRoles.SUPER_ADMIN)) {
    return next();
  }
  res.status(403).json({ message: "Forbidden - Requires product admin privileges" });
};

// Middleware to check if user has super admin role
const isSuperAdmin = (req: Request, res: Response, next: NextFunction) => {
  if (req.isAuthenticated() && req.user.role === userRoles.SUPER_ADMIN) {
    return next();
  }
  res.status(403).json({ message: "Forbidden - Requires super admin privileges" });
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication routes
  setupAuth(app);

  // Category routes
  app.get("/api/categories", async (req, res) => {
    try {
      const categories = await storage.getCategories();
      res.json(categories);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch categories" });
    }
  });

  app.get("/api/categories/:slug", async (req, res) => {
    try {
      const category = await storage.getCategoryBySlug(req.params.slug);
      if (!category) {
        return res.status(404).json({ message: "Category not found" });
      }
      res.json(category);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch category" });
    }
  });

  // Product routes
  app.get("/api/products", async (req, res) => {
    try {
      let products;
      const categoryId = req.query.categoryId ? parseInt(req.query.categoryId as string) : undefined;
      
      if (categoryId) {
        products = await storage.getProductsByCategory(categoryId);
      } else {
        products = await storage.getProducts();
      }
      
      res.json(products);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch products" });
    }
  });

  app.get("/api/products/top", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 3;
      const products = await storage.getTopRatedProducts(limit);
      res.json(products);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch top products" });
    }
  });

  app.get("/api/products/:slug", async (req, res) => {
    try {
      const product = await storage.getProductBySlug(req.params.slug);
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      
      // Get product features
      const features = await storage.getProductFeatures(product.id);
      
      res.json({ ...product, features });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch product" });
    }
  });

  // Review routes
  app.get("/api/reviews", async (req, res) => {
    try {
      let reviews;
      const productId = req.query.productId ? parseInt(req.query.productId as string) : undefined;
      const userId = req.query.userId ? parseInt(req.query.userId as string) : undefined;
      
      if (productId) {
        reviews = await storage.getReviewsByProduct(productId);
      } else if (userId) {
        reviews = await storage.getReviewsByUser(userId);
      } else {
        reviews = await storage.getReviews();
      }
      
      // Get user data for each review and add it to response
      const reviewsWithUser = await Promise.all(reviews.map(async (review) => {
        const user = await storage.getUser(review.userId);
        // Exclude user password from response
        const { password, ...userWithoutPassword } = user || {};
        return {
          ...review,
          user: userWithoutPassword
        };
      }));
      
      res.json(reviewsWithUser);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch reviews" });
    }
  });

  app.get("/api/reviews/latest", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 3;
      const reviews = await storage.getLatestReviews(limit);
      
      // Get user and product data for each review
      const reviewsWithDetails = await Promise.all(reviews.map(async (review) => {
        const user = await storage.getUser(review.userId);
        const product = await storage.getProductById(review.productId);
        
        // Exclude user password from response
        const { password, ...userWithoutPassword } = user || {};
        
        return {
          ...review,
          user: userWithoutPassword,
          product
        };
      }));
      
      res.json(reviewsWithDetails);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch latest reviews" });
    }
  });

  app.post("/api/reviews", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "You must be logged in to write a review" });
      }
      
      // Validate request body
      const reviewData = insertReviewSchema.parse({
        ...req.body,
        userId: req.user?.id
      });
      
      // Check if product exists
      const product = await storage.getProductById(reviewData.productId);
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      
      // Check if user has already reviewed this product
      const userReviews = await storage.getReviewsByUser(req.user.id);
      const existingReview = userReviews.find(r => r.productId === reviewData.productId);
      
      if (existingReview) {
        return res.status(400).json({ message: "You have already reviewed this product" });
      }
      
      const review = await storage.createReview(reviewData);
      res.status(201).json(review);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid review data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create review" });
    }
  });

  // Comparison route
  app.get("/api/comparison", async (req, res) => {
    try {
      const productIds = (req.query.ids as string).split(",").map(id => parseInt(id));
      
      if (!productIds.length || productIds.some(isNaN)) {
        return res.status(400).json({ message: "Invalid product IDs" });
      }
      
      const products = await Promise.all(
        productIds.map(async (id) => {
          const product = await storage.getProductById(id);
          if (!product) return null;
          
          const features = await storage.getProductFeatures(id);
          const reviews = await storage.getReviewsByProduct(id);
          
          return {
            ...product,
            features,
            reviewCount: reviews.length
          };
        })
      );
      
      // Filter out null values (products that don't exist)
      const validProducts = products.filter(p => p !== null);
      
      res.json(validProducts);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch comparison data" });
    }
  });

  // ===== ADMIN ROUTES =====
  // User management routes (Super Admin only)
  app.get("/api/admin/users", isSuperAdmin, async (req, res) => {
    try {
      const users = await storage.getUsersByRole(req.query.role as UserRole || userRoles.USER);
      // Remove passwords from response
      const safeUsers = users.map(user => {
        const { password, ...userWithoutPassword } = user;
        return userWithoutPassword;
      });
      res.json(safeUsers);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  app.patch("/api/admin/users/:id/role", isSuperAdmin, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const { role } = req.body;
      
      if (!Object.values(userRoles).includes(role)) {
        return res.status(400).json({ message: "Invalid role" });
      }
      
      const user = await storage.updateUserRole(userId, role);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Remove password from response
      const { password, ...userWithoutPassword } = user;
      
      res.json(userWithoutPassword);
    } catch (error) {
      res.status(500).json({ message: "Failed to update user role" });
    }
  });

  // Category management routes (Product Admin or Super Admin)
  app.post("/api/admin/categories", isProductAdmin, async (req, res) => {
    try {
      const categoryData = insertCategorySchema.parse(req.body);
      const category = await storage.createCategory(categoryData);
      res.status(201).json(category);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid category data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create category" });
    }
  });

  // Product management routes (Product Admin or Super Admin)
  app.post("/api/admin/products", isProductAdmin, async (req, res) => {
    try {
      const productData = insertProductSchema.parse(req.body);
      
      // Check if category exists
      const category = await storage.getCategoryById(productData.categoryId);
      if (!category) {
        return res.status(400).json({ message: "Category does not exist" });
      }
      
      const product = await storage.createProduct(productData);
      res.status(201).json(product);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid product data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create product" });
    }
  });

  app.post("/api/admin/products/:id/features", isProductAdmin, async (req, res) => {
    try {
      const productId = parseInt(req.params.id);
      
      // Check if product exists
      const product = await storage.getProductById(productId);
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      
      const featureData = insertProductFeatureSchema.parse({
        ...req.body,
        productId
      });
      
      const feature = await storage.createProductFeature(featureData);
      res.status(201).json(feature);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid feature data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create product feature" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
