import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";
import createMemoryStore from "memorystore";
import session from "express-session";
import { 
  users, User, InsertUser,
  categories, Category, InsertCategory,
  products, Product, InsertProduct,
  productFeatures, ProductFeature, InsertProductFeature,
  reviews, Review, InsertReview,
  userRoles, UserRole
} from "@shared/schema";

const scryptAsync = promisify(scrypt);

// Function to hash passwords using scrypt
async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserRole(userId: number, role: UserRole): Promise<User | undefined>;
  getUsersByRole(role: UserRole): Promise<User[]>;
  
  // Category operations
  getCategories(): Promise<Category[]>;
  getCategoryById(id: number): Promise<Category | undefined>;
  getCategoryBySlug(slug: string): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;
  
  // Product operations
  getProducts(): Promise<Product[]>;
  getProductById(id: number): Promise<Product | undefined>;
  getProductBySlug(slug: string): Promise<Product | undefined>;
  getProductsByCategory(categoryId: number): Promise<Product[]>;
  getTopRatedProducts(limit: number): Promise<Product[]>;
  createProduct(product: InsertProduct): Promise<Product>;
  
  // Product features
  getProductFeatures(productId: number): Promise<ProductFeature[]>;
  createProductFeature(feature: InsertProductFeature): Promise<ProductFeature>;
  
  // Review operations
  getReviews(): Promise<Review[]>;
  getReviewById(id: number): Promise<Review | undefined>;
  getReviewsByProduct(productId: number): Promise<Review[]>;
  getReviewsByUser(userId: number): Promise<Review[]>;
  getLatestReviews(limit: number): Promise<Review[]>;
  createReview(review: InsertReview): Promise<Review>;
  
  sessionStore: session.Store;
}

export class MemStorage implements IStorage {
  private usersData: Map<number, User>;
  private categoriesData: Map<number, Category>;
  private productsData: Map<number, Product>;
  private productFeaturesData: Map<number, ProductFeature>;
  private reviewsData: Map<number, Review>;
  
  private userIdCounter: number;
  private categoryIdCounter: number;
  private productIdCounter: number;
  private productFeatureIdCounter: number;
  private reviewIdCounter: number;
  
  sessionStore: session.Store;

  constructor() {
    this.usersData = new Map();
    this.categoriesData = new Map();
    this.productsData = new Map();
    this.productFeaturesData = new Map();
    this.reviewsData = new Map();
    
    this.userIdCounter = 1;
    this.categoryIdCounter = 1;
    this.productIdCounter = 1;
    this.productFeatureIdCounter = 1;
    this.reviewIdCounter = 1;
    
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000, // prune expired entries every 24h
    });
    
    // Initialize with sample data
    this.initSampleData();
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.usersData.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.usersData.values()).find(
      (user) => user.username.toLowerCase() === username.toLowerCase()
    );
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.usersData.values()).find(
      (user) => user.email.toLowerCase() === email.toLowerCase()
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    
    // Create user object with proper null values for optional fields
    const user: User = { 
      ...insertUser, 
      id,
      fullName: insertUser.fullName || null,
      title: insertUser.title || null,
      company: insertUser.company || null,
      role: insertUser.role || userRoles.USER,
      avatar: null, 
      createdAt: new Date()
    };
    
    this.usersData.set(id, user);
    return user;
  }
  
  async updateUserRole(userId: number, role: UserRole): Promise<User | undefined> {
    const user = await this.getUser(userId);
    if (!user) return undefined;
    
    const updatedUser: User = {
      ...user,
      role
    };
    
    this.usersData.set(userId, updatedUser);
    return updatedUser;
  }
  
  async getUsersByRole(role: UserRole): Promise<User[]> {
    return Array.from(this.usersData.values()).filter(
      user => user.role === role
    );
  }

  // Category operations
  async getCategories(): Promise<Category[]> {
    return Array.from(this.categoriesData.values());
  }

  async getCategoryById(id: number): Promise<Category | undefined> {
    return this.categoriesData.get(id);
  }
  
  async getCategoryBySlug(slug: string): Promise<Category | undefined> {
    return Array.from(this.categoriesData.values()).find(
      (category) => category.slug === slug
    );
  }

  async createCategory(insertCategory: InsertCategory): Promise<Category> {
    const id = this.categoryIdCounter++;
    const category: Category = {
      ...insertCategory,
      id,
      description: insertCategory.description || null,
      productCount: insertCategory.productCount || null
    };
    this.categoriesData.set(id, category);
    return category;
  }

  // Product operations
  async getProducts(): Promise<Product[]> {
    return Array.from(this.productsData.values());
  }

  async getProductById(id: number): Promise<Product | undefined> {
    return this.productsData.get(id);
  }
  
  async getProductBySlug(slug: string): Promise<Product | undefined> {
    return Array.from(this.productsData.values()).find(
      (product) => product.slug === slug
    );
  }

  async getProductsByCategory(categoryId: number): Promise<Product[]> {
    return Array.from(this.productsData.values()).filter(
      (product) => product.categoryId === categoryId
    );
  }
  
  async getTopRatedProducts(limit: number): Promise<Product[]> {
    return Array.from(this.productsData.values())
      .sort((a, b) => (b.avgRating || 0) - (a.avgRating || 0))
      .slice(0, limit);
  }

  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const id = this.productIdCounter++;
    const product: Product = { 
      ...insertProduct, 
      id,
      logo: insertProduct.logo || null,
      avgRating: 0, 
      reviewCount: 0,
      createdAt: new Date()
    };
    this.productsData.set(id, product);
    return product;
  }

  // Product features
  async getProductFeatures(productId: number): Promise<ProductFeature[]> {
    return Array.from(this.productFeaturesData.values()).filter(
      (feature) => feature.productId === productId
    );
  }

  async createProductFeature(insertFeature: InsertProductFeature): Promise<ProductFeature> {
    const id = this.productFeatureIdCounter++;
    const feature: ProductFeature = { ...insertFeature, id };
    this.productFeaturesData.set(id, feature);
    return feature;
  }

  // Review operations
  async getReviews(): Promise<Review[]> {
    return Array.from(this.reviewsData.values());
  }

  async getReviewById(id: number): Promise<Review | undefined> {
    return this.reviewsData.get(id);
  }

  async getReviewsByProduct(productId: number): Promise<Review[]> {
    return Array.from(this.reviewsData.values())
      .filter((review) => review.productId === productId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async getReviewsByUser(userId: number): Promise<Review[]> {
    return Array.from(this.reviewsData.values())
      .filter((review) => review.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }
  
  async getLatestReviews(limit: number): Promise<Review[]> {
    return Array.from(this.reviewsData.values())
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
      .slice(0, limit);
  }

  async createReview(insertReview: InsertReview): Promise<Review> {
    const id = this.reviewIdCounter++;
    const review: Review = { 
      ...insertReview, 
      id,
      pros: insertReview.pros || null,
      cons: insertReview.cons || null,
      createdAt: new Date() 
    };
    this.reviewsData.set(id, review);
    
    // Update product rating
    const productId = insertReview.productId;
    const product = await this.getProductById(productId);
    
    if (product) {
      const productReviews = await this.getReviewsByProduct(productId);
      const totalRating = productReviews.reduce((sum, r) => sum + r.rating, 0);
      const avgRating = totalRating / productReviews.length;
      
      const updatedProduct: Product = {
        ...product,
        avgRating,
        reviewCount: productReviews.length
      };
      
      this.productsData.set(productId, updatedProduct);
    }
    
    return review;
  }
  
  private async initSampleData() {
    // Sample categories
    const categories = [
      { name: "Communication", slug: "communication", description: "Tools for team collaboration and messaging", icon: "message", productCount: 123 },
      { name: "CRM", slug: "crm", description: "Customer Relationship Management software", icon: "customer-service", productCount: 98 },
      { name: "Analytics", slug: "analytics", description: "Business intelligence and data analysis tools", icon: "line-chart", productCount: 87 },
      { name: "E-Commerce", slug: "e-commerce", description: "Online retail and shopping platforms", icon: "shopping-cart", productCount: 76 },
      { name: "Project Management", slug: "project-management", description: "Task tracking and team coordination tools", icon: "calendar-check", productCount: 104 },
      { name: "DevOps", slug: "devops", description: "Development and operations tools", icon: "computer", productCount: 92 },
      { name: "Security", slug: "security", description: "Data protection and cybersecurity solutions", icon: "shield-check", productCount: 65 },
      { name: "Marketing", slug: "marketing", description: "Brand promotion and advertising tools", icon: "folder-chart", productCount: 118 }
    ];
    
    for (const category of categories) {
      await this.createCategory(category as InsertCategory);
    }
    
    // Sample products
    const products = [
      {
        name: "Slack",
        slug: "slack",
        description: "Slack is a messaging app for business that connects people to the information they need. By bringing people together to work as one unified team, Slack transforms the way organizations communicate.",
        logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/d/d5/Slack_icon_2019.svg/2048px-Slack_icon_2019.svg.png",
        categoryId: 1, // Communication
      },
      {
        name: "Asana",
        slug: "asana",
        description: "Asana is a work management platform for teams. It helps teams organize and manage all their work, from small projects to strategic initiatives.",
        logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/3/3b/Asana_logo.svg/1280px-Asana_logo.svg.png",
        categoryId: 5, // Project Management
      },
      {
        name: "Notion",
        slug: "notion",
        description: "Notion is an all-in-one workspace where you can write, plan, collaborate and get organized. It allows you to take notes, add tasks, manage projects & more.",
        logo: "https://upload.wikimedia.org/wikipedia/commons/4/45/Notion_app_logo.png",
        categoryId: 5, // Project Management
      }
    ];
    
    for (const product of products) {
      await this.createProduct(product as InsertProduct);
    }
    
    // Sample product features
    const productFeatures = [
      { productId: 1, feature: "Team Messaging" },
      { productId: 1, feature: "Integrations" },
      { productId: 1, feature: "File Sharing" },
      { productId: 2, feature: "Task Management" },
      { productId: 2, feature: "Collaboration" },
      { productId: 2, feature: "Kanban" },
      { productId: 3, feature: "Note Taking" },
      { productId: 3, feature: "Wiki" },
      { productId: 3, feature: "Database" }
    ];
    
    for (const feature of productFeatures) {
      await this.createProductFeature(feature as InsertProductFeature);
    }
    
    // Create demo user with hashed password
    const hashedPassword = await hashPassword("password123");
    const demoUser = await this.createUser({
      username: "demo",
      password: hashedPassword,
      email: "demo@example.com",
      fullName: "Demo User",
      title: "Software Developer",
      company: "Demo Company"
    });
    
    // Create admin users
    await this.createUser({
      username: "admin",
      password: await hashPassword("admin123"),
      email: "admin@example.com",
      fullName: "Admin User",
      title: "Product Manager",
      company: "Demo Company",
      role: userRoles.PRODUCT_ADMIN
    });
    
    await this.createUser({
      username: "superadmin",
      password: await hashPassword("superadmin123"),
      email: "superadmin@example.com",
      fullName: "Super Admin",
      title: "CEO",
      company: "Demo Company",
      role: userRoles.SUPER_ADMIN
    });
    
    // Sample reviews
    const reviews = [
      {
        userId: demoUser.id,
        productId: 1, // Slack
        title: "Transformed our team communication",
        content: "Our team's productivity skyrocketed after moving to Slack. The integrations are fantastic and the interface is intuitive. It has become an essential part of our daily workflow.",
        rating: 5,
        pros: ["Easy to use", "Great integrations"],
        cons: ["Can get overwhelming"],
      },
      {
        userId: demoUser.id,
        productId: 2, // Asana
        title: "Great for project tracking, but has limitations",
        content: "Asana has been instrumental in keeping our projects organized. The UI is clean and intuitive. However, I wish they would improve their reporting features and add more customization options.",
        rating: 4,
        pros: ["Visual organization", "User-friendly"],
        cons: ["Limited reporting"],
      },
      {
        userId: demoUser.id,
        productId: 3, // Notion
        title: "The ultimate organization tool",
        content: "Notion has replaced multiple tools for me. I use it for notes, task management, wiki, and database functionality. It's extremely flexible, though it can have a bit of a learning curve for new users.",
        rating: 5,
        pros: ["Versatile", "Customizable"],
        cons: ["Learning curve"],
      }
    ];
    
    for (const review of reviews) {
      await this.createReview(review as InsertReview);
    }
  }
}

export const storage = new MemStorage();
